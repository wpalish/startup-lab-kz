---
name: SapaLot
description: The inherited working cabinet for frozen bilingual sample plans, explicit integer readings and separate model decisions.
colors:
  primary: "#126653"
  primary-hover: "#0b5343"
  navy: "#183e60"
  ink: "#172e45"
  page: "#edf3f8"
  surface: "#ffffff"
  line: "#b9cbd9"
  navigation-surface: "#dce9f3"
  muted: "#46627a"
  input-stroke: "#7894aa"
  link: "#174e7e"
  pending: "#795200"
  error: "#942721"
  error-surface: "#fff0ee"
  focus: "#bd671a"
  selection-surface: "#b7ded2"
  selection-ink: "#132f29"
typography:
  primary-heading:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
    fontSize: "2rem"
    lineHeight: 1.15
    letterSpacing: "-0.025em"
  section-heading:
    fontSize: "1.3rem"
  brand:
    fontSize: "1.4rem"
    fontWeight: 740
  body:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
  label:
    fontWeight: 600
  supporting:
    fontSize: "0.9rem"
  compact-helper:
    fontSize: "0.85rem"
    lineHeight: 1.5
  preformatted:
    fontSize: "0.85rem"
rounded:
  control: "7px"
  panel: "12px"
spacing:
  evidence-gap: "0.4rem"
  inline-gap: "0.5rem"
  action-gap: "0.6rem"
  control-inset: "0.7rem"
  table-cell: "0.9rem"
  unit: "1rem"
  page-inline: "1.25rem"
  panel-inset: "1.4rem"
  section: "2rem"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-default:
    backgroundColor: "{colors.navy}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "{spacing.control-inset}"
    width: "100%"
  panel:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
    padding: "{spacing.panel-inset}"
  navigation-current:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  inspection-matrix:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
    width: "100%"
  matrix-hint:
    textColor: "{colors.muted}"
    typography: "{typography.compact-helper}"
  snapshot-disclosure:
    padding: "0.7rem 0"
  saved-cell-evidence:
    padding: "1rem 0"
  error-notice:
    backgroundColor: "{colors.error-surface}"
    textColor: "{colors.error}"
    rounded: "{rounded.control}"
    padding: "{spacing.unit}"
---

# Design System: SapaLot

## Overview

**Creative North Star: "The Shared Work Cabinet"**

SapaLot continues the owned KadamRun Shared Work Cabinet: a navy identity shell, pale blue workspace, flat white labelled forms, restrained green explicit actions and system typography. The inherited authority is [KadamRun's design system](../kadam-run/DESIGN.md) at the owned source commit `0e6af4d1dbc296f6ddb9a4f6ed1a1adca9476a44`, as recorded in the [surface brief](.impeccable/surfaces/public-app-js.md). That commit identifies the incumbent source; it is not a digest of this document. This scan preserves that identity and takes the actual SapaLot implementation as the token and component authority.

The cabinet is direct, readable and procedural. Written ownership and saved completeness lead into a native table of exact sample/metric cells. Bilingual authored evidence stays inspectable through native disclosures. A single-cell save, an unsaved report preview, a frozen computed report and a separate manual model decision have visibly different labels and places in the flow. Their visual separation supports the bounded synthetic product described in [PRODUCT.md](PRODUCT.md).

**Key Characteristics:**

- Inherited navy shell, cool workspace and flat white native controls.
- Restrained system type, connected labels and tabular numeric evidence.
- Exact RU/KK plan text, inclusive boundaries and authored units remain inspectable.
- Written incomplete, outside and within states accompany saved counts and values.
- Explicit saves, separately labelled previews and read-only retained input preserve state clarity.

## Colors

The frontmatter owns the values extracted from [the stylesheet](public/styles.css). Names retain the incumbent palette. Sidecar tonal ramps are derived inspection metadata, not additional implemented colors.

### Primary

- **Working Green / Deep Working Green** (`primary`, `primary-hover`): explicit primary and submit actions, including publication, lot creation, one-cell saves, report previews and model decisions. The label names the exact effect; green alone does not assert that a record was saved.

### Secondary

- **Cabinet Navy** (`navy`): the identity header, baseline button rule, secondary borders and navigation text.
- **Link Blue** (`link`): ordinary links and field carets.

### Tertiary

- **Pending Amber** (`pending`): an inherited available helper style; the current matrix expresses its comparison states in text rather than applying this color.
- **Error Red / Pale Error** (`error`, `error-surface`): the refused-request notice and its written explanation.
- **Focus Amber** (`focus`): the visible outline for keyboard-focusable controls, headings and disclosures.
- **Soft Selection Green / Selection Ink** (`selection-surface`, `selection-ink`): native text selection.

### Neutral

- **Cabinet Ink** (`ink`): body copy, authored instructions and values.
- **Cool Workspace / White Surface** (`page`, `surface`): page ground, panels, native fields, notices and tables.
- **Divider Blue / Navigation Mist** (`line`, `navigation-surface`): one-pixel boundaries, navigation ground and column/row header backgrounds.
- **Supporting Slate / Field Slate** (`muted`, `input-stroke`): hints/footer and native field strokes/scrollbars.

**The Inherited Shell Rule.** Extend the existing Shared Work Cabinet palette, type and native control grammar.

## Typography

One system stack serves the shell, headings and controls; [the HTML](public/index.html) loads no font asset. The task heading, section heading, heavier brand and connected label roles are recorded in frontmatter. Body size and unspecified heading weights retain browser defaults. Paragraphs have a maximum measure (72ch) and line height (1.6). Tables use tabular numerals; table type reduces to the supporting size at the narrow breakpoint. Audit JSON uses native preformatted text with the smaller recorded size, preserved whitespace and wrapping.

The shell is Russian. Authored plan instructions and metric labels use separate RU and KK nodes; unit labels use `lang="und"`. Instruction paragraphs preserve visible line breaks. Reading and report rationales use the lot's chosen language. Raw timestamps, bounds, integer strings, versions and digests remain exact text. The inherited system stack is operational typography, with no separate display face or ornamental lettering. Source: [authored nodes and forms](public/app.js), [type, table and wrapping rules](public/styles.css).

**The Authored Text Rule.** Preserve authored RU/KK nodes, exact integer strings, units and rationale; do not rewrite frozen evidence for visual consistency.

## Layout

Header and navigation share inline padding (`max(1.25rem, calc((100% - 1160px) / 2))`). Main is centered at maximum width (1200px), padding (`2rem 1.25rem`) and minimum height (75vh). Navigation and peer-action groups wrap. Search and archive visibility precede record tables; labelled white panels hold forms. Optional two-column work and paired-row grids remain in inherited CSS, while the lot detail and cell editor use single-column content. Source: [shell and responsive styles](public/styles.css), [renderers](public/app.js).

At the stacked breakpoint (700px), optional grids become one column, panel/page insets reduce, header identity narrows and navigation adapts. At the narrow table breakpoint (600px), search stacks, table cells have a minimum width (140px), table type reduces and the separate matrix guidance becomes visible. Both record and matrix tables use labelled focusable wrappers to own horizontal overflow. The sample header keeps a minimum width (5rem) and no internal wrapping; long other cells wrap. The matrix is a wide native table inside its scroller, rather than a set of replacement cards.

The lot detail begins with code/title → immutable owner and written comparison state → saved/required count, outside count and version → editable/closed explanation → exact-plan disclosure → matrix guidance and table. The owner report form or a written ownership restriction follows. A frozen report exposes actor/time, rationale, digest and saved cell-version disclosures, then a separately labelled saved model decision or eligible other-admin form. Refresh/return actions and any separate retained-input panel follow the current state. Cell editing begins with sample/metric, lot owner, inclusive bounds and both labels before its connected value and rationale fields. This is the current surface composition, not a rule forcing every future cabinet screen into the same order.

**The Matrix Guidance Rule.** At narrow widths, put readable guidance outside each matrix scroller; name saved values and comparisons, and name fill/change actions when the matrix is editable.

### Evidence scope and freshness

The [finish review](docs/finish-review.json) records **ship** after a fresh full source/30-capture review and a subsequent verdict pass resolving its sole F1 finding. The final pass scores F1 together with the prior full review; it is not a second complete product or security audit. Review history remains in [the recapture record](docs/finish-review-recapture-history.json) and [the full-review fix record](docs/finish-review-full-fix-history.json).

The original 30 named captures are historical workflow evidence from source before F1: twelve actual-1113 CSS-pixel desktop full-page JPEGs in [capture provenance](docs/capture-provenance.json), six actual-400 × 700 CSS-pixel native full-page PNGs at DPR2 in [mobile phase 1](docs/mobile-phase1.json), and twelve actual-400 × 700 CSS-pixel ordinary viewport JPEGs at DPR1 in [mobile phase 2](docs/mobile-phase2.json). Phase 2 records top and scrolled sections separately; a nonzero scroll position is not a document-top capture. Phase 1's right-pan filename does not establish a captured right-pan position: its metadata records keyboard scrolling before the native capture reset horizontal position. These older images do not show the new guidance.

The four current-source F1 captures are recorded in [hint-review-fix.json](docs/hint-review-fix.json). They are ordinary viewport JPEGs with exact pre/post CSS dimensions and scroll positions, not full-page images or composites:

| Current F1 capture | CSS viewport | Recorded scroll Y | Purpose |
| --- | --- | --- | --- |
| [Read-only matrix guidance](docs/F1-readonly-hint-400-viewport.jpg) | 400 × 700 | 279 | Visible saved-value/comparison guidance outside a read-only matrix. |
| [Editable matrix guidance](docs/F1-editable-hint-400-viewport.jpg) | 400 × 700 | 398.5 | Visible guidance also names fill/change actions. |
| [Editable lot header](docs/F1-editable-header-400-viewport.jpg) | 400 × 700 | 0 | Current editable header and initial matrix context. |
| [Wide lot view](docs/F1-desktop-1126-viewport.jpg) | 1126 × 1087 | 0 | The narrow-only guidance is hidden at the actual wide width. |

Canonical review aliases `desktop.png` and `mobile.png` are byte-identical aliases of the current wide JPEG and editable-header JPEG respectively; the extension is not their MIME type or a full-page claim. The F1 provenance records current `public/app.js` SHA-256 `20d491ba5ab56df02ac5ee28120aea6be1aeeaca0b2b9abd6c19104f48d341dd`, stylesheet `8b8cedce3509ef78158123406b388c45aa99d9c6c56b502188fce33917ef7d03` and HTML `ddb351252c684b9eed3e8ec09bb686b182623171ecc582c9d160406ff7b3806b`. Historical mobile JavaScript has a different hash by design. This documenter compared local hashes and read source/provenance; it did not repeat browser interaction, raster review, rendering, tests or detector execution.

The reviewed evidence covers the supplied synthetic workflows and actual recorded dimensions. It does not establish 390px or 1440px behavior, touch or screen-reader operation, an exhaustive accessibility/security audit, backend coverage of the unsampled server/store portions, physical quality or customer acceptance. Different accounts do not establish different humans. No new image, component implementation or visual world was introduced by this documentation pass.

## Elevation & Depth

No shadow, transition, animation or backdrop treatment is defined. Pale ground, white native surfaces, one-pixel boundaries and section spacing establish hierarchy. Button hover brightens the existing surface; primary hover also deepens the fill without motion. Programmatic task-heading focus, cell-value focus, preview-heading focus and the focused refusal notice carry continuity after content replacement. Source: [states and focus styles](public/styles.css), [focus behavior](public/app.js).

**The Flat Cabinet Rule.** Use surface color, borders and spacing for hierarchy; preserve the incumbent absence of ornamental elevation and motion.

## Shapes

Controls, notices and inherited fieldsets use the smaller recorded radius; panels and table wrappers use the larger one. Buttons and native disclosure summaries have minimum height (44px). Textareas begin at minimum height (100px) and resize vertically. Disclosure markers remain native. Borders remain one pixel. There are no implemented chips, floating overlays, custom pickers or icon decorations to extend. Source: [native component styles](public/styles.css).

## Components

### Buttons, Fields and Navigation

Primary and submit buttons are green; secondary refresh, return, open and archive controls are white with navy text and border. The navy-filled baseline button rule remains defined; it is not an additional new action priority. Buttons use the recorded inset and radius, weight (600), hover brightness (1.13), disabled opacity (0.55) and the final disabled `cursor: not-allowed`. The active request button disables during its request. Focus-visible uses an amber outline (3px) with offset (3px). Source: [button states](public/styles.css), [request and button helpers](public/app.js).

Native text, search, password, number, file, select and rationale fields keep connected labels, full width, white ground, field stroke and blue carets. Required fields retain native validation. The reading value is a text input with numeric input mode, maximum length (8) and a connected written canonical-integer hint; it is not a floating-point number picker. Its hint references both the numeric guidance and notice. Rationale textareas keep their lot language. Source: [field helpers, cell editor and settings](public/app.js).

The navy header contains the linked brand and account/role. Active collection navigation uses a white bordered button with `aria-current="page"`; inactive buttons are transparent on Navigation Mist. Lots is the initial collection. The skip link becomes visible on focus. Task headings receive programmatic focus. The notice has `role="status"`, `aria-live="polite"` and a focus target; it hides when empty and uses the pale error treatment on refusal. These source semantics are not a screen-reader certification. Source: [HTML shell](public/index.html), [navigation and notices](public/app.js).

### Record Table and Inspection Matrix

The collection table has column-scoped headers, wrapping text, tabular numerals, a secondary **Открыть** control and a written empty-filter state. The inspection matrix adds a caption naming the lot, row-scoped sample headers, metric code and RU/KK labels, exact inclusive range/unit, saved integer or **Не заполнено**, and **Нет значения / Внутри границ / Вне границ**. Eligible owners also see a final column of sample/metric-specific fill or change buttons. Comparison is expressed in words, not color alone. Source: [record and matrix renderers](public/app.js).

The narrow-screen hint is a sibling before the scroller, so it can be read before discovering the right-hand columns. Read-only wording names values and comparisons; editable wording also names the buttons. It is reused in the unsaved report-preview matrix. The source-defined narrow breakpoint controls its visibility; the current F1 packet confirms the supplied actual-400 and actual-1126 views only.

### Frozen Plan Disclosure

The native **Точный опубликованный план этой партии** disclosure contains code/version, title, authored RU/KK instructions, sample count and ordered metric positions with bilingual labels, codes, inclusive bounds and authored units. Unit text explicitly carries no conversion or physical-meaning assurance. Publication preview says **Предпросмотр · ещё не опубликован** before a separate explicit publication action. Source: [snapshot and publication renderers](public/app.js).

**The Frozen Evidence Rule.** Keep the lot's exact plan and saved cell versions inspectable; a newer plan never visually replaces its snapshot.

### Cell Save, Full Report and Model Decision

The owner edits one selected sample/metric cell at a time. **Сохранить только эту ячейку** returns to the lot with a written one-cell-save notice. The report form is separate: **Проверить полный отчёт без записи** reveals **Предпросмотр полного отчёта · ещё не закрыт**, a written result and a read-only preview matrix. Only **Закрыть именно этот полный отчёт** attempts the explicit close. Editing the report rationale clears the preview. A refused close disables and retires the old commit control and labels the preview **Запись отказала · обновите партию и проверьте снова**. Source: [cell and lot detail renderers](public/app.js).

A saved report says the matrix is closed and values no longer editable. **Неизменный отчёт** contains actor/time, authored closing rationale, digest and the native **Сохранённые основания и версии всех ячеек** disclosure. Each cell entry exposes sample, metric code, saved reading version, rationale, exact value and update time. The computed result remains separate from **Сохранённое решение модели**. An eligible different admin sees a native decision select and rationale field; outside-limits reports expose rejection only. The saved decision remains labelled as a manual model mark. Source: [lot detail](public/app.js).

**The Written State Rule.** Name editable, unsaved, refused, frozen and manually decided states in text; a count, color or preview never asserts that an action was recorded.

### Refresh and Retained Input

Explicit cell/lot refresh captures the current unsaved fields, fetches state and restores them to an eligible form without sending them. If the report or decision has made that action unavailable, **Несохранённый ввод после обновления** appears in a separate white panel. Its labelled read-only textareas expose the unsaved value, previous decision or rationale for copying. This panel never replaces a saved report, saved reading or decision. Source: [retained input and refresh branches](public/app.js).

**The Unsaved Recovery Rule.** Preserve value, decision and rationale across explicit refresh; keep unavailable retained input read-only and separate from saved evidence.

### Documentation Examples and Unchanged Drift

The [schemaVersion 2 sidecar](.impeccable/design.json) contains ten scoped, self-contained static examples extracted from these native patterns: three button rules, navigation, the numeric field/hint, the cell-editing panel, the inspection matrix/guidance, the frozen-plan disclosure, the frozen report/separate decision and read-only retained input. Examples use synthetic values, no application handlers and no new interface behavior. Button examples use `type="button"`; fields and disclosures retain native behavior. These are documentation snippets, not additional captures or executed workflows.

No craft-floor refusal is promoted into a token or new house style. Legacy PRODUCT/schema/configuration drift is outside this two-file documentation write and remains unmodified; it is not a new design-system rule. Inherited CSS utilities without a current renderer remain available source rules, not evidence that those components were reviewed. Product scope, backend correctness and publication/release status remain governed by their own records.

## Do's and Don'ts

### Do:

- Do retain the inherited navy shell, pale workspace, green explicit actions and white native controls.
- Do keep connected labels, visible focus, native disclosure markers and scoped table headers.
- Do preserve authored RU/KK nodes, integer strings, inclusive bounds, units, versions and rationale.
- Do show ownership, written comparison state and saved completeness before the matrix actions.
- Do place narrow matrix guidance outside the scroller and name actions when editing is available.
- Do distinguish one-cell saves, an unsaved full-report preview, a frozen report and a separate manual model decision.
- Do retire a refused report commit and require a refreshed preview before a new close attempt.
- Do retain unsaved fields across refresh and show unavailable input separately read-only for copying.
- Do let long text, digests, timestamps and table cells wrap without fixed-height cropping.

### Don't:

- Don't replace the owned cabinet identity with vendor styling, ornamental media, display lettering or animation.
- Don't replace native selects, tables or disclosures with decorative imitations.
- Don't use color alone to communicate missing, within or outside comparisons.
- Don't present a preview, retained field or incomplete matrix as a saved full report.
- Don't visually merge the computed report result with the separate manual model decision.
- Don't imply that a manual model mark proves physical release, quality or certification.
- Don't present different account names as proof of different human reviewers.
- Don't treat derived sidecar ramps or static examples as additional implemented interface states.
- Don't describe historical captures as showing F1 guidance or expand the recorded review into unverified dimensions, touch, screen-reader, security or full-product approval.
