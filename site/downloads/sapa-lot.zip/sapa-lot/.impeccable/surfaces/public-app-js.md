---
version: 1
slug: "public-app-js"
primary_target: "public/app.js"
related_targets: []
---

Scope: SapaLot public/app.js. Operate extension of the owned KadamRun Shared Work Cabinet. Inherit actual navy/pale/green/native system; no new identity or conceptual tournament.
## Direction contract
THESIS: Every frozen sample/metric cell has an explicit authored value; only a complete matrix can freeze a deterministic comparison report.
OWN-WORLD: Owned daylight working cabinet, navy shell, pale workspace, white native labelled forms, restrained green explicit actions, tabular numeric evidence and native bilingual disclosures. Incumbent KadamRun0e6af4d1dbc296f6ddb9a4f6ed1a1adca9476a44, not Retool visuals.
STORY: Admin publishes a numeric plan. Owner creates a synthetic lot, fills/edits one cell at a time, inspects missing/outside cells, previews and explicitly closes the full matrix. A different admin may save one manual model decision. No physical inspection/release or automatic completion claimed.
FIRST VIEWPORT: Lot code/title, immutable owner, saved completeness and explicit incomplete/outside/within wording precede sample table. Table shows sample, bilingual metric, inclusive range, saved value and exact comparison. One cell form has connected labels, integer hint and retained value/rationale after stale refusal and refresh. Full report is visibly closed/read-only; independent model decision separate from computed comparison.
FORM: Narrow code-led extension; task settled by owner request to continue100. Native controls, visible focus, scoped headers, wrapping action groups, status text beyond color. Frozen RU/KK keeps lang. Preview says unsaved; explicit write says saved. After finalisation stale unsaved input remains separately read-only for copying, never auto submitted.
FINISH: unreviewed and undocumented is unfinished; finish with fresh review/verdict, DESIGN.md + sidecar and raster provenance. Actual browser dimensions only; no390/1440 claim from failed capability. No full accessibility/security/physical-quality claim.
