# Reference 19: Retool

Source: [official Retool homepage](https://retool.com/), read on 2026-10-25 UTC; research record: `work/program/next-reference-19.json` in the programme workspace.

The official page describes internal applications, controlled access, data connections and audit logging. These are vendor descriptions. Vendor AI, security, production readiness, customer results and metrics were not independently verified. No account, form, demo, snippet, CLI, MCP or integration was used.

SapaLot is an original bounded application in the internal-tool category: a published numeric plan, an owner-filled synthetic sample matrix, a complete deterministic comparison report and a separate administrator's manual model decision. It is not a general application builder or a Retool integration. No vendor source, brand, interface assets or proprietary code were copied.

The unique workflow is comparison of each frozen sample/metric cell against inclusive numeric limits, with completeness required before closing the whole report. QuralGate checks one typed tool-request model; BekitChange applies an approved record change. SapaLot does neither of those operations.

All browser values are fictional. Numeric conformity does not prove physical quality, true measurements, sufficient sampling, certification, compliance or an actual release of goods. The v0.1 contract and limits are in [PRODUCT.md](../PRODUCT.md).

Current status: local implementation with 27 passing tests and desktop workflow/preservation evidence. The fresh UI review requires an actual mobile viewport capture. There is no ship verdict or counted public release yet.
