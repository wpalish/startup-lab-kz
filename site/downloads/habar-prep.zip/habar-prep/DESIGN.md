---
name: HabarPrep
description: An inherited working cabinet for checked recipient preparation and immutable snapshots without external messages.
colors:
  primary: "#126653"
  primary-hover: "#0b5343"
  navy: "#183e60"
  ink: "#172e45"
  page: "#edf3f8"
  surface: "#ffffff"
  line: "#b9cbd9"
  navigation-surface: "#dce9f3"
  muted: "#46627a"
  input-stroke: "#7894aa"
  link: "#174e7e"
  pending: "#795200"
  error: "#942721"
  error-surface: "#fff0ee"
  focus: "#bd671a"
  selection-surface: "#b7ded2"
  selection-ink: "#132f29"
typography:
  primary-heading:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
    fontSize: "2rem"
    lineHeight: 1.15
    letterSpacing: "-0.025em"
  section-heading:
    fontSize: "1.3rem"
  brand:
    fontSize: "1.4rem"
    fontWeight: 740
  body:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
  label:
    fontWeight: 600
  supporting:
    fontSize: "0.9rem"
rounded:
  control: "7px"
  panel: "12px"
spacing:
  inline-gap: "0.5rem"
  action-gap: "0.6rem"
  control-inset: "0.7rem"
  unit: "1rem"
  page-inline: "1.25rem"
  panel-inset: "1.4rem"
  section: "2rem"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-default:
    backgroundColor: "{colors.navy}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "{spacing.control-inset}"
    width: "100%"
  panel:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
    padding: "{spacing.panel-inset}"
  navigation-current:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
---

# Design System: HabarPrep

## Overview

**Creative North Star: "The Shared Work Cabinet"**

HabarPrep extends the documented ArnaLead / OrtaInbox / Startup Lab working cabinet. This ordinary Operate extension keeps the pale blue ground, navy header and navigation, white labelled forms, green primary actions, and native controls. The incumbent system remains the visual authority; this record captures the implemented extension without introducing a new visual world.

Its character is direct, flat, and readable. System typography, thin borders, native checkboxes, tables, and disclosure controls make operational evidence the focus. The checklist and preview reuse the cabinet grammar; saved history and current rechecks remain visibly separate.

**Key Characteristics:**

- Inherited navy navigation and pale blue workspace.
- Green labelled actions and white bordered form panels.
- System typography with a fixed-size primary heading.
- Native recipient selection, reason disclosures, and visible keyboard focus.

## Colors

The inherited cool palette uses navy for orientation and Working Green for primary actions. Exact implemented values live in the frontmatter; the sidecar's inherited tonal ramps are documentation previews, not runtime colors.

### Primary

- **Working Green** (`primary`, `primary-hover`): submit buttons, the explicit snapshot freeze, and the available status utility.

### Secondary

- **Cabinet Navy** (`navy`): header, default filled buttons, navigation text, and secondary action borders.
- **Link Blue** (`link`): text links and the field caret.

### Tertiary

- **Pending Amber** (`pending`): the inherited pending-state utility.
- **Error Red / Pale Error** (`error`, `error-surface`): focused refusal feedback.
- **Focus Amber** (`focus`): keyboard focus outline.
- **Soft Selection Green / Selection Ink** (`selection-surface`, `selection-ink`): native text selection.

### Neutral

- **Cabinet Ink** (`ink`): root text.
- **Cool Workspace** (`page`): page ground and scrollbar track.
- **White Surface** (`surface`): forms, selected navigation, and notices.
- **Divider Blue** (`line`): panel and fieldset borders, tables, and evidence dividers.
- **Navigation Mist** (`navigation-surface`): navigation strip and table headings.
- **Supporting Slate** (`muted`): helper copy and footer.
- **Field Slate** (`input-stroke`): field borders and scrollbar thumb.

**The Inherited Shell Rule.** Extend the current ArnaLead / OrtaInbox / Startup Lab cabinet instead of replacing its palette, typography, or navigation grammar.

## Typography

**Display and Body Font:** the system stack in the frontmatter, also inherited by fields and buttons. No webfont or separate display face is loaded. Unspecified sizes and weights follow native defaults.

- **Primary heading:** fixed 2rem, line height 1.15, letter spacing -0.025em, margin `0 0 0.8rem`.
- **Section heading:** 1.3rem, margin `2rem 0 0.75rem`.
- **Brand:** 1.4rem, weight 740.
- **Body paragraphs:** maximum 72ch, line height 1.6, margin `0.5rem 0 1rem`. Root body size and line height are not explicitly declared.
- **Labels and buttons:** weight 600. Labels use `1rem 0 0.35rem` margin; the first label removes its top margin. Recipient labels override weight to 400; their legend uses 650.
- **Supporting copy:** 0.9rem. Narrow table hints and preformatted audit text use 0.85rem; hints and small help text have line height 1.5.
- **Evidence text:** preserves authored line breaks. Preformatted audit text wraps anywhere; tables and date inputs use tabular numerals.

**The Fixed Heading Rule.** Keep the primary heading at the implemented fixed 2rem size; no fluid display scale is defined.

## Layout

Header and navigation share an inline inset of `max(1.25rem, calc((100% - 1160px) / 2))`. The header is a centered flex row with space between brand and identity, 1rem gap, and 1.1rem vertical padding. Navigation has a 0.5rem gap and 0.7rem vertical padding.

Main has maximum width 1200px, automatic inline margins, `2rem 1.25rem` padding, and minimum height 75vh. Form panels use `min-width: 0`. The inherited optional work grid is `minmax(0, 1fr) minmax(260px, 0.8fr)` with a 2rem gap; paired rows use two equal columns with a 1rem gap. The preparation screen uses a vertical sequence: labelled selector, recipient fieldset, checking actions, evidence, then explicit freeze. Evidence uses a top divider, 1rem top padding and margin, and a 0.4rem grid gap.

At 700px and below, grids stack, the work gap becomes 1.2rem, main padding becomes `1.4rem 1rem`, and panel padding becomes 1rem. Header items align to the top; identity is 0.8rem with maximum width 140px. Navigation wraps with 0.6rem padding and initially flexible buttons. At 600px and below, navigation buttons use `flex: auto`, search tools stack, and tables use 0.9rem type with minimum 140px cells.

Search tools use `minmax(200px, 500px) auto` and `0.5rem 1.2rem` gaps above the narrow breakpoint. Tables scroll within their own focusable wrapper; a narrow-screen hint explains the scroll. Action rows wrap with a 0.6rem gap and 1rem top margin. Long headings, identity, disclosures, evidence, and footer copy wrap instead of truncating. The recipient checklist stays one column at all captured widths.

## Elevation & Depth

No box shadow, backdrop effect, transition, or animation is defined. White panels, pale page and navigation fills, one-pixel borders, and whitespace separate regions. Button hover uses brightness and the primary background change without motion.

## Shapes

Controls, notices, and the recipient fieldset use 7px corners; panels and table wrappers use 12px. Borders are one pixel. Full-width fields have 0.7rem padding; textareas start at 100px height and resize vertically. Buttons and disclosure summaries have minimum height 44px. Native checkboxes keep the browser's checkbox appearance; no custom accent color is declared.

## Components

### Buttons

Labelled native actions use `0.65rem 1rem` padding, 7px corners, minimum height 44px, and weight 600. Primary and submit buttons use Working Green and white text; hover uses `primary-hover` plus the general brightness filter of 1.13. Default buttons use Cabinet Navy; secondary buttons use white with navy text and border. Disabled controls use opacity 0.55 and `cursor: not-allowed`. Keyboard focus is a 3px amber outline with 3px offset. Narrow-screen buttons have maximum width 100%.

### Cards / Containers

White form panels use a Divider Blue border, 12px corners, and 1.4rem padding, reduced to 1rem below 700px. The login panel is capped at 480px. Evidence remains on the page ground with dividers rather than adding another card shell.

### Inputs / Fields

Native input, select, and textarea controls use white fill, Cabinet Ink, Field Slate borders, 7px corners, and Link Blue carets. Generated labels connect to field IDs. Archived record fields use native read-only or disabled presentation. Error feedback appears above the title in the focused polite live status notice; failed submissions preserve the existing form.

### Navigation

The navy header shows linked product identity and current user/role. The pale navigation strip uses text buttons: transparent when inactive, white with a Divider Blue border and `aria-current="page"` when current. Navigation wraps on mobile. The skip link becomes visible on keyboard focus.

### Recipient Checklist

A semantic fieldset groups labelled native checkboxes beneath a **Получатели** legend. It has a Divider Blue border, 7px corners, `1.2rem 0` margin, 1rem padding, and `min-width: 0`. Legend weight is 650 with `0 0.3rem` padding. Each label is a flex row with centered alignment, 0.7rem gap, normal weight, wrapping text, and minimum height 44px. Checkbox width is auto and flex is `0 0 auto`. Archived contacts remain visibly labelled; preview supplies the exclusion reason. The empty fieldset directs the user to add recipients.

### Checked Preview and Snapshot Freeze

Counts and the no-external-send limitation lead the evidence section, followed by notice code/version and title. Each recipient is a native disclosure: summary names code, alias, and inclusion/exclusion reason; expanded content shows language, record version, expiry, recorded basis, and available authored text. Disclosure entries have bottom dividers and `1rem 0` padding; the first removes top padding and the final removes its divider. Summary stays `display: list-item` with native marker, minimum height 44px, and `0.7rem 0` padding.

The green **Сохранить проверенный снимок** action follows the reasons and stretches with its evidence grid. It is disabled when eligible count is zero. Editing selection clears the pending preview and action; a generation guard discards obsolete responses. A stale external change produces focused refusal feedback above the preserved earlier form/preview. These source behaviors are documented without implying every state was independently rerun in this pass.

### Immutable History and Current Recheck

Saved detail leads with preparation timestamp/author and **Тогда** counts, followed by the historical notice/version and audience disclosures. **Перепроверить сейчас** renders a distinct **Сейчас** evidence section below the saved report. It does not replace the historical report. Keep the repeated disclosure grammar and full reasons so different versions remain inspectable.

**The Native Disclosure Rule.** Preserve the native details/summary marker and interaction when presenting saved or current evidence.

### Tables

Native tables are full width with collapsed borders, left/top aligned cells, 0.9rem cell padding, one-pixel bottom dividers, wrapping text, and maximum cell width 28ch. Header cells use Navigation Mist and 0.9rem text. Action text remains unbroken; the last row has no bottom divider. The wrapper owns horizontal scrolling and keyboard focus.

## Do's and Don'ts

### Do:

- **Do** inherit the navy header, pale workspace, white form surfaces, and green primary action.
- **Do** retain system typography and the fixed primary heading scale.
- **Do** keep native checkbox and disclosure behavior with visible keyboard focus.
- **Do** allow long identities and evidence to wrap with min-width: 0 and overflow-wrap: anywhere.
- **Do** keep inclusion and exclusion reasons before the freeze action and distinguish saved history from current rechecks.

### Don't:

- **Don't** replace the inherited shell with a new visual identity.
- **Don't** imply that an internal preference or saved snapshot proves legal consent or permits external sending.
- **Don't** overwrite historical evidence with a current recheck.
- **Don't** remove native disclosure markers or clip long evidence to make a layout fit.
