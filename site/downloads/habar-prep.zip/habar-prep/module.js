import{createHash}from'node:crypto';import{F,S,R,C,rows,byId,required,changed,immutable,unique,summary}from'./core/rules.js';
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b),hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex'),positive=x=>Number.isSafeInteger(x)&&x>0;
const contactKeys=['id','code','alias','language','preference','validUntil','reason','version','archived'];
const noticeKeys=['id','code','title','bodyRu','bodyKk','status','version','archived'];
const pick=(x,keys)=>Object.fromEntries(keys.map(k=>[k,x[k]]));
export function assess(contact,notice,time){
 let reason='eligible';
 if(contact.archived)reason='archived';else if(contact.preference==='blocked')reason='blocked';else if(contact.preference!=='allowed')reason='unknown';else if(!Number.isFinite(Date.parse(contact.validUntil))||Date.parse(contact.validUntil)<=time)reason='expired';else if(!(contact.language==='ru'?notice.bodyRu:notice.bodyKk))reason='missing_language';
 return{contact,eligible:reason==='eligible',reason,text:reason==='eligible'?(contact.language==='ru'?notice.bodyRu:notice.bodyKk):null};
}
export function preview(state,input,time=Date.now()){
 const notice=byId(state,'notices',input.notice);required(!notice.archived&&notice.status==='active','Выберите действующее уведомление.');
 required(Array.isArray(input.audience)&&input.audience.length>0&&input.audience.length<=50&&new Set(input.audience).size===input.audience.length,'Выберите от 1 до 50 разных получателей.');
 const report={notice:pick(notice,noticeKeys),audience:[...input.audience].sort().map(id=>assess(pick(byId(state,'contacts',id),contactKeys),notice,time))};
 return{report,digest:hash(report),eligible:report.audience.filter(x=>x.eligible).length,excluded:report.audience.filter(x=>!x.eligible).length};
}
export const reasons={eligible:'Допущен внутри журнала',archived:'Контакт в архиве',blocked:'Записан отказ',unknown:'Предпочтение неизвестно',expired:'Срок записи истёк',missing_language:'Нет текста на выбранном языке'};
export function createDefinition({now=()=>Date.now()}={}){return{
 slug:'habar-prep',reference:5,title:'HabarPrep',description:'Ручная подготовка уведомления: предпросмотр допуска получателей и неизменный снимок без отправки.',limitations:'Псевдонимы · Одна общая область · Запись предпочтения не юридическое согласие · Без внешних сообщений',
 collections:[
 C('contacts','Получатели',[F('code','Код получателя'),F('alias','Псевдоним'),S('language','Язык',[['ru','RU'],['kk','KK']],{default:'ru'}),S('preference','Внутреннее предпочтение',[['unknown','Неизвестно'],['allowed','Разрешено внутри журнала'],['blocked','Отказ']],{default:'unknown'}),F('validUntil','Срок записи (ISO с часовым поясом)','datetime',{required:false,help:'Для разрешённой записи нужен будущий срок. Например 2030-12-31T18:00:00+05:00.'}),F('reason','Основание записи','textarea')],{labelField:'code',addLabel:'Добавить получателя',description:'Только разрешённые псевдонимы. Внутренняя запись не доказывает юридическое согласие; история версий сохраняется.'}),
 C('notices','Уведомления',[F('code','Код уведомления'),F('title','Название'),F('bodyRu','Текст RU','textarea',{required:false}),F('bodyKk','Текст KK','textarea',{required:false}),S('status','Состояние',[['draft','Черновик'],['active','Действует']],{default:'draft'})],{labelField:'code',addLabel:'Создать уведомление',description:'Авторский текст без перевода. Отсутствующая языковая версия исключает соответствующего получателя.'}),
 C('preparations','Подготовки',[R('notice','Уведомление','notices',{readOnly:true}),F('audience','Получатели','references',{ref:'contacts',readOnly:true})],{addLabel:'Подготовить список',description:'Сначала проверьте список, затем явно сохраните неизменный снимок. Ничего не отправляется.'})],
 preview(state,input){return preview(state,input,now());},
 normalizeRow(key,row,state,old,actor){
  if(key==='preparations'){
   required(!old,'Подготовленный снимок неизменен. Сделайте новый предпросмотр.');const at=now(),p=preview(state,row,at);required(p.eligible>0,'Ни один получатель не допущен. Снимок не сохранён.');return{...row,...p,preparedBy:actor.name,preparedAt:new Date(at).toISOString()};
  }
  if(key==='notices'){
   required(row.bodyRu.length>0||row.bodyKk.length>0,'Напишите хотя бы одну языковую версию.');const version=old?old.version+(Object.keys(row).some(k=>row[k]!==old[k])?1:0):1;return{...row,version};
  }
  if(row.preference==='allowed'&&(!old||old.preference!==row.preference||old.validUntil!==row.validUntil))required(Date.parse(row.validUntil)>now(),'Новая разрешённая запись требует будущего срока.');
  const version=old?old.version+(Object.keys(row).some(k=>row[k]!==old[k])?1:0):1;
  const history=old?.history||[];return{...row,version,history:!old||version!==old.version?[...history,{version,...row,by:actor.name,at:new Date(now()).toISOString()}]:history};
 },
 validate(state,before,command){
  unique(rows(state,'contacts'),'code','Код получателя');unique(rows(state,'notices'),'code','Код уведомления');
  for(const c of rows(state,'contacts')){
   required(positive(c.version)&&Array.isArray(c.history)&&c.history.length===c.version,'Неверная история предпочтений.');
   for(let i=0;i<c.history.length;i++){const h=c.history[i];required(h.version===i+1&&['unknown','allowed','blocked'].includes(h.preference)&&['ru','kk'].includes(h.language)&&typeof h.reason==='string'&&h.reason.length>0&&typeof h.alias==='string'&&h.alias.length>0&&typeof h.code==='string'&&h.code.length>0&&typeof h.by==='string'&&h.by.length>0&&Number.isFinite(Date.parse(h.at)),'Неверная запись истории.');if(h.preference==='allowed')required(Number.isFinite(Date.parse(h.validUntil)),'Нет срока разрешённой записи.');}
   const last=c.history.at(-1);required(['code','alias','language','preference','validUntil','reason','version'].every(k=>same(last[k],c[k])),'Последняя запись истории не совпадает с получателем.');
   const old=changed(before,'contacts',c.id);if(old&&command.operation==='archive')immutable(old,c,['code','alias','language','preference','validUntil','reason','version','history']);
  }
  for(const n of rows(state,'notices'))required(positive(n.version)&&(n.bodyRu.length>0||n.bodyKk.length>0),'Неверная версия уведомления.');
  for(const p of rows(state,'preparations')){
   byId(state,'notices',p.notice);for(const id of p.audience)byId(state,'contacts',id);
   const report=p.report;required(report&&report.notice?.id===p.notice&&Array.isArray(report.audience)&&report.audience.length===p.audience.length&&new Set(p.audience).size===p.audience.length&&report.audience.length>0&&report.audience.length<=50,'Неверный снимок списка.');
   const n=report.notice;required(positive(n.version)&&n.status==='active'&&n.archived===false&&['code','title','bodyRu','bodyKk'].every(k=>typeof n[k]==='string')&&(n.bodyRu.length>0||n.bodyKk.length>0),'Неверный снимок уведомления.');
   required(typeof p.preparedBy==='string'&&p.preparedBy.length>0&&Number.isFinite(Date.parse(p.preparedAt)),'Неверная история подготовки.');
   const expected={notice:n,audience:report.audience.map(e=>{const c=e.contact;required(c&&positive(c.version)&&['ru','kk'].includes(c.language)&&['allowed','blocked','unknown'].includes(c.preference)&&typeof c.archived==='boolean'&&['id','code','alias','validUntil','reason'].every(k=>typeof c[k]==='string'),'Неверный снимок получателя.');return assess(c,n,Date.parse(p.preparedAt));})};
   required(same(report,expected)&&same(report.audience.map(e=>e.contact.id),[...p.audience].sort())&&hash(report)===p.digest,'Нарушена целостность снимка подготовки.');
   required(p.eligible===report.audience.filter(e=>e.eligible).length&&p.eligible>0&&p.excluded===report.audience.length-p.eligible,'Неверные итоги подготовки.');
   const old=changed(before,'preparations',p.id);if(!old&&command.operation!=='restore')required(typeof command.previewHash==='string'&&command.previewHash===p.digest,'Предпросмотр устарел или отсутствует. Проверьте список заново.');
   if(old)immutable(old,p,['notice','audience','report','digest','eligible','excluded','preparedAt','preparedBy']);
  }
 },
 summarize(state){return rows(state,'preparations').filter(p=>!p.archived).map(p=>{let current;try{current=preview(state,p,now()).eligible;}catch{current=0;}return summary(p.report.notice.code+' · снимокv'+p.report.notice.version,'Тогда допущено: '+p.eligible+';исключено: '+p.excluded,'Сейчас по тем же ссылкам допущено: '+current+'. История не разрешает отправку.');});}
};}
export default createDefinition();
