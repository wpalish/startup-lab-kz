# Workspace — implemented surface record

## Authority, mode, and task

Mode: **Operate**. HabarPrep is an ordinary local extension of the documented ArnaLead / OrtaInbox / Startup Lab cabinet. [PRODUCT.md](../../PRODUCT.md) owns its bounded product truth; [DESIGN.md](../../DESIGN.md) records the inherited visual tokens. The current HTML, CSS, and JavaScript preserve ArnaLead's palette, system type, flat depth, buttons, fields, navigation, tables, responsive breakpoints, and native disclosures. The incumbent ArnaLead files remain unchanged.

The coordinator manually selects one authored RU/KK notice and pseudonymous recipients, inspects inclusion/exclusion reasons, then explicitly freezes the checked preparation. Saved history remains separate from a current recheck. No new visual-world, concept seed, quality board, approved comp, comp build state, or comp diff applies: **seed:none(local extension)**.

## Direction contract

THESIS: Make recipient eligibility and exclusions inspectable before freezing a preparation.

OWN-WORLD: Existing navy header, pale blue workspace, white labelled form, green explicit action, system type, thin borders and native details.

STORY: Select notice and pseudonymous contacts, read included/excluded reasons, explicitly freeze the checked snapshot, then compare history with a fresh recheck.

FIRST VIEWPORT: Identity/nav, title/instruction and one primary action;preview shows counts and named reasons before the freeze action.

FORM: Existing cabinet list/detail flow. No concept seed or comp; seed:none(local extension). Signature interaction: a data/time change after preview refuses confirmation without overwriting history.

FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance

## Current composition and states

`public/index.html` supplies Russian document language, a keyboard skip link, linked brand and signed-in identity, task navigation, polite live status feedback, main content, and footer. `public/app.js` supplies lists/search/archive, labelled forms, preparation, immutable snapshot details, and settings. Dynamic copy uses text nodes. `public/styles.css` retains the inherited visual grammar and adds only a native recipient fieldset/checklist.

The preparation screen flows vertically through a labelled notice selector, one-column recipient checklist, green **Проверить список** action, and checked preview. The preview starts with eligible/excluded counts, a no-external-send explanation, and notice code/version. Recipient summaries state code, alias, and reason; their native disclosures reveal language, record version, expiry, basis, and available authored text. The green **Сохранить проверенный снимок** action comes after these reasons and fills the evidence grid width.

| State | Visible behavior and meaning |
| --- | --- |
| No recipients | The fieldset asks the coordinator to add recipients. Native notice selection remains labelled. |
| Checked preview | Counts and named reasons precede the explicit freeze. Exclusions distinguish refusal, unknown preference, expiry, archive, and missing language text. |
| Zero eligible | The freeze action is disabled. |
| Local form edit | Input/change clears the old preview and freeze action. A generation guard also discards an obsolete preview response. |
| External stale change | Focused error feedback directs the user to refresh before saving; the earlier selection and preview remain visible. |
| Saved snapshot | Timestamp/author and **Тогда** counts lead the exact historical report. Later preference changes do not rewrite it. |
| Current recheck | **Перепроверить сейчас** creates a separate **Сейчас** report below the historical evidence. |
| Search empty | The list explains that no records match and suggests adding a record or changing search. |

Summaries retain native markers and a minimum 44px target. Headings, evidence, aliases, dates, and footer copy wrap. At narrow widths navigation wraps, the checklist remains one column, and table overflow stays in its own focusable wrapper. The surface introduces no motion.

## Product boundaries carried by the surface

Records are pseudonymous. An allowed/unknown/blocked preference is an internal journal record, not legal consent. A saved preparation does not permit external sending. RU/KK text is authored manually; there is no translation, WhatsApp/Meta/AI integration, message sending, scheduling, delivery, or import. All staff see one shared workspace. Synthetic examples are visibly labelled and do not establish customer outcomes.

## Evidence inspected

The documenter read PRODUCT.md, the current `public/index.html`, `public/styles.css`, and `public/app.js`, the ArnaLead DESIGN.md and schemaVersion 2 sidecar, the existing surface contract, [the fresh finish review](../../../../program/habar-prep-finish-review.json), and supplied browser proof. It opened all five supplied captures without browser actions:

| Capture | Dimensions | Inspected content |
| --- | --- | --- |
| [Desktop](../../../../../outputs/products/habar-prep-desktop-full.png) | 1440 × 1644 | Current checked preview: three checked aliases, one KK eligible, two refusals, notice v2, expanded KK detail, explicit freeze, footer. |
| [Mobile](../../../../../outputs/products/habar-prep-mobile-full.png) | 390 × 1946 | Same current state with wrapped navigation, reasons, and full-width freeze. Supplied browser proof records actual document scrollWidth 390. |
| [User width](../../../../../outputs/products/habar-prep-user-1280.png) | 1280 × 1644 | Same current checked state at the supplied 1280px width. |
| [Stale refusal](../../../../../outputs/products/habar-prep-stale-refusal.png) | 1280 × 1538 | Explicit data-changed refusal above preserved selection and earlier notice-v1 preview. Historic interaction capture before the punctuation-spacing-only edit. |
| [History and recheck](../../../../../outputs/products/habar-prep-history-recheck.png) | 1280 × 1465 | Saved **Тогда: 1** report remains above separate **Сейчас: 0** report. Historic interaction capture before the punctuation-spacing-only edit. |

All supplied captures show their named content from the document top with footer and no blank or black capture regions. They are screenshot evidence only, not shipping marketing assets. No generated/sourced illustration or other shipping raster was added.

## Review and documentation completion

[The fresh finish review](../../../../program/habar-prep-finish-review.json) records **ship**, a full UI review of the supplied five captures and current HTML/CSS/JavaScript with no material fixes. Its fidelity matrix covers type/material/ground, shell/navigation, selector/checklist, preview reasons and explicit freeze, local invalidation, external stale refusal, immutable history/current recheck, mobile adaptation, and product truth. The 17 passing automated checks and browser interactions are supplied execution evidence, not independently rerun by the reviewer or documenter; neither ran a browser, server, or external security audit.

The single supplied static detector output is `[]`; no second detector ran. The surface contract is retained, including its exact FINISH line. Review: complete — **ship** at the supplied UI/source scope. Documentation: complete — token-bearing DESIGN.md, schemaVersion 2 `.impeccable/design.json`, and this surface record. The FINISH condition is discharged at that scope; there are no shipping raster assets requiring provenance metadata.

## Write boundary and existing context drift

This pass writes only `DESIGN.md`, `.impeccable/design.json`, and `.impeccable/surfaces/workspace.md`. It changes no runtime source, tests, screenshots, incumbent design records, or other documents. Sidecar snippets are self-contained representations of current components; inherited tonal ramps remain documentation previews rather than new runtime tokens.

The context loader reports a legacy PRODUCT.md schema and unset `.impeccable/config.json` buildPath. Those pre-existing records were not repaired: product schema refresh belongs to `init`, and buildPath selection concerns future Persuade/Experience surfaces. This Operate extension remains within its recorded scope.
