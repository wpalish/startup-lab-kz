# Workspace

Mode: Operate. Local extension of HabarPrep/ArnaLead, no new visual world or comp.

## Direction contract

THESIS: Make graph completeness and exact-version rehearsal visible before any synthetic trace is saved.
OWN-WORLD: Existing navy identity/navigation, pale blue workspace, white labelled forms, green explicit actions, system type, thin borders and native disclosure.
STORY: Author draft nodes/choices, validate and freeze a complete graph, rehearse one published version, inspect its saved exact trace.
FIRST VIEWPORT: Identity/nav and task title lead. Publication detail shows version and node/choice totals; rehearsal shows pinned version/language, current text and explicit choices before saving a terminal trace.
FORM: Existing cabinet list/editor with native scripted choices. seed: none (local extension). Signature interaction: draft edits do not rewrite publications or traces; a choice outside the current published node is rejected.
FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance

## Implemented expression

- Visual authority: the existing HabarPrep / ArnaLead / StartupLab Operate cabinet. `DESIGN.md` and the schemaVersion 2 `.impeccable/design.json` record the inherited implementation; the incumbent HabarPrep files are preserved. No comp, visual-world replacement, shipping raster, or new motion system is owed. Review PNGs are evidence, not shipping artwork.
- Graph check: labelled scenario selector, explicit check action, counts and code/version/start context, then native node disclosures. Each disclosure retains its native marker, separate authored RU/KK bodies, and RU/KK choice labels pointing to target codes. The explicit publication action follows the checked graph.
- Publication: detail identifies author/time, counts, and the frozen graph version. Draft edits do not substitute for that publication. Stale state uses focused refusal feedback above the retained form/evidence. The exact revision check is server behavior; a preview does not establish that a human read or approved it.
- Rehearsal: publication and language selectors precede the path. Code, exact graph version, and selected language repeat above ordered trace entries. The current question and authored choices lead to a terminal model result; complete trace save appears only there. Changing publication/language clears the result. Back recomputes the shorter path.
- Semantics: interface chrome stays Russian. Authored RU/KK fields, graph bodies, graph label spans, selected-language choices, and saved trace text carry their actual language. After each successful path response, focus moves deliberately to the current question or terminal heading, with the inherited amber outline and a route onward to choices/save.
- Saved history: code/version/language and performer/time lead the immutable ordered trace. The wording states synthetic rehearsal and model-only handover. Archive closes new use without rewriting the readable historical publication or trace. This record does not turn the prototype into a real bot, message sender, translation service, or staff handover.

## Quality bar commitments

Preserve the inherited shell and native disclosures; keep exact version/language context visible with the ordered choices; allow long authored bodies to wrap; preserve form state on refusal; keep authored language semantics separate from interface instructions; and maintain current-question/terminal focus through the rehearsal. Do not replace immutable publication or saved-trace evidence with a later draft. These are surface commitments grounded in the implemented source and supplied review evidence, not a claim that every reachable state has been independently exercised here.

## Finish evidence and scope

Documentation checked `PRODUCT.md`, `README.md`, `public/index.html`, `public/styles.css`, `public/app.js`, this direction contract, the incumbent `../habar-prep/DESIGN.md` and `../habar-prep/.impeccable/design.json`, and `../../program/jol-flow-finish-review.json`.

All five current capture files were opened during documentation: `.impeccable/review/desktop.png` (1440), `user-1280.png` (1280), `mobile.png` (390), `active-desktop.png` (1440), and `active-mobile.png` (390). The first three show the saved SYN-F1 v12 KK trace in START → FORMAT → HUMAN order. The active captures show the terminal focus outline, model-only result, and full trace save. The supplied images show their document tops and full content without blank regions or visible clipping.

The initial finish review returned `fix` for F1 (rehearsal keyboard continuity) and F2 (authored language semantics). The final verdict is `ship`: the reviewer scored exactly F1 and F2 resolved, with no regressions recorded from that fix batch. This was a verdict pass over those two findings, not a new whole-surface clean bill, security audit, complete mobile/touch review, screen-reader session, compliance certification, integration check, or independent repeat of the supplied runtime/test observations. Documentation adds no runtime or test changes. Synthetic/model-only limitations remain visible.
