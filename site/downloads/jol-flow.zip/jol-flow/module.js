import{createHash}from'node:crypto';import{F,S,R,C,rows,byId,required,changed,immutable,unique,summary}from'./core/rules.js';
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b),hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex'),positive=x=>Number.isSafeInteger(x)&&x>0;
const uuid=x=>typeof x==='string'&&/^[a-f0-9-]{36}$/.test(x),text=x=>typeof x==='string'&&x.trim().length>0&&x.length<=8000,fold=x=>x.normalize('NFC').trim().toLocaleLowerCase();
const pick=(x,keys)=>Object.fromEntries(keys.map(k=>[k,x[k]]));
export function analyse(graph){
 required(graph&&graph.flow&&positive(graph.flow.version)&&uuid(graph.flow.id)&&text(graph.flow.code)&&text(graph.flow.title),'Неверный снимок сценария.');
 required(Array.isArray(graph.nodes)&&graph.nodes.length>0&&graph.nodes.length<=60&&Array.isArray(graph.edges)&&graph.edges.length<=360,'Граф: от 1 до 60 узлов и до 360 переходов.');
 const nodes=new Map(graph.nodes.map(n=>[n.id,n])),edges=new Set();required(nodes.size===graph.nodes.length,'Повторный ID узла.');unique(graph.nodes,'code','Код узла');
 required(nodes.has(graph.flow.entry),'Выберите действующий стартовый узел этого сценария.');
 for(const n of graph.nodes)required(uuid(n.id)&&text(n.code)&&['question','finish','handover'].includes(n.kind)&&text(n.bodyRu)&&text(n.bodyKk),'Каждый узел требует типа, кода и обоих текстов RU/KK.');
 for(const e of graph.edges){required(uuid(e.id)&&!edges.has(e.id)&&nodes.has(e.source)&&nodes.has(e.target)&&text(e.labelRu)&&text(e.labelKk),'Переход требует действующих узлов и обоих вариантов RU/KK.');edges.add(e.id);}
 const outgoing=id=>graph.edges.filter(e=>e.source===id);
 for(const n of graph.nodes){const choices=outgoing(n.id);required(n.kind==='question'?choices.length>=2&&choices.length<=6:choices.length===0,n.kind==='question'?'У вопроса должно быть от 2 до 6 переходов.':'Терминал не может иметь исходящих переходов.');for(const language of ['labelRu','labelKk'])required(new Set(choices.map(e=>fold(e[language]))).size===choices.length,'Варианты одного вопроса должны различаться на каждом языке.');}
 const visited=new Set(),visiting=new Set();function visit(id){required(!visiting.has(id),'В сценарии обнаружен цикл.');if(visited.has(id))return;visiting.add(id);for(const e of outgoing(id))visit(e.target);visiting.delete(id);visited.add(id);}visit(graph.flow.entry);
 required(visited.size===nodes.size,'Есть узлы, недостижимые от старта.');
 return{nodes:graph.nodes.length,edges:graph.edges.length,terminals:graph.nodes.filter(n=>n.kind!=='question').length};
}
export function graphFor(state,id){const f=byId(state,'flows',id);required(!f.archived,'Сценарий в архиве.');const snapshot={flow:pick(f,['id','code','title','entry','version']),nodes:rows(state,'nodes').filter(n=>n.flow===id&&!n.archived).map(n=>pick(n,['id','code','kind','bodyRu','bodyKk'])).sort((a,b)=>a.id.localeCompare(b.id)),edges:rows(state,'edges').filter(e=>e.flow===id&&!e.archived).map(e=>pick(e,['id','source','target','labelRu','labelKk'])).sort((a,b)=>a.id.localeCompare(b.id))};return{snapshot,digest:hash(snapshot),report:analyse(snapshot)};}
export function walk(snapshot,choices,language,complete=false){
 analyse(snapshot);required(['ru','kk'].includes(language),'Выберите RU или KK.');required(Array.isArray(choices)&&choices.length<=60&&choices.every(uuid),'Неверный путь репетиции.');
 let current=snapshot.nodes.find(n=>n.id===snapshot.flow.entry);const trace=[];
 for(const id of choices){const e=snapshot.edges.find(e=>e.id===id&&e.source===current.id);required(current.kind==='question'&&e,'Выбор не принадлежит текущему узлу опубликованной версии.');trace.push({nodeId:current.id,code:current.code,text:language==='ru'?current.bodyRu:current.bodyKk,kind:current.kind,choice:{id:e.id,label:language==='ru'?e.labelRu:e.labelKk,target:e.target}});current=snapshot.nodes.find(n=>n.id===e.target);}
 const done=current.kind!=='question';if(done)trace.push({nodeId:current.id,code:current.code,text:language==='ru'?current.bodyRu:current.bodyKk,kind:current.kind,choice:null});if(complete)required(done,'Завершите путь до терминала перед сохранением.');
 return{trace,complete:done,outcome:done?current.kind:null,current:{id:current.id,code:current.code,kind:current.kind,text:language==='ru'?current.bodyRu:current.bodyKk},options:done?[]:snapshot.edges.filter(e=>e.source===current.id).map(e=>({id:e.id,label:language==='ru'?e.labelRu:e.labelKk}))};
}
function currentRelease(state,id){const r=byId(state,'releases',id);required(!r.archived&&!byId(state,'flows',r.flow).archived,'Публикация или сценарий в архиве. Новые репетиции закрыты.');return r;}
export default{
 slug:'jol-flow',reference:6,title:'JolFlow',description:'Авторский граф RU/KK: проверка, неизменная публикация и синтетическая репетиция по версии.',limitations:'Одна общая область · Без Instagram/WhatsApp, AI, перевода и реальных сообщений',
 collections:[
 C('flows','Сценарии',[F('code','Код сценария'),F('title','Название'),R('entry','Стартовый узел','nodes',{required:false})],{labelField:'code',addLabel:'Создать сценарий',description:'Сначала сохраните сценарий без старта, затем добавьте его узлы и переходы и выберите старт.'}),
 C('nodes','Узлы',[R('flow','Сценарий','flows',{readOnly:true}),F('code','Код узла'),S('kind','Тип узла',[['question','Вопрос'],['finish','Завершение'],['handover','К сотруднику (модель)']],{default:'question'}),F('bodyRu','Текст RU','textarea',{required:false}),F('bodyKk','Текст KK','textarea',{required:false})],{labelField:'code',addLabel:'Добавить узел',description:'Черновик может быть неполным. Для публикации нужны оба текста и 2–6 вариантов у вопроса; у терминала исходящих нет.'}),
 C('edges','Переходы',[R('source','Из узла','nodes',{readOnly:true}),R('target','В узел','nodes'),F('labelRu','Вариант RU'),F('labelKk','Вариант KK')],{addLabel:'Добавить переход',description:'Оба узла принадлежат одному сценарию. Циклы и недостижимые узлы блокируют публикацию, а не сохранение черновика.'}),
 C('releases','Публикации',[R('flow','Сценарий','flows',{readOnly:true})],{writeRole:'admin',addLabel:'Проверить и опубликовать',description:'Администратор фиксирует точный проверенный граф. Это внутренняя публикация модели, не запуск бота в канале.'}),
 C('rehearsals','Репетиции',[R('release','Публикация','releases',{readOnly:true}),S('language','Язык',[['ru','RU'],['kk','KK']],{default:'ru',readOnly:true}),F('choices','Путь','path',{required:false,readOnly:true})],{addLabel:'Начать репетицию',description:'Пройдите конкретную публикацию до терминала и сохраните полную трассу. Терминал не выполняет внешнее действие.'})
 ],
 preview(state,input){if(input.mode==='graph')return{kind:'graph',...graphFor(state,input.flow)};required(input.mode==='walk','Неизвестная проверка.');const r=currentRelease(state,input.release);return{kind:'walk',release:r.id,flowCode:r.snapshot.flow.code,version:r.graphVersion,...walk(r.snapshot,input.choices,input.language)};},
 normalizeRow(key,row,state,old,actor){
  if(key==='flows'){if(row.entry)required(byId(state,'nodes',row.entry).flow===old?.id&&!byId(state,'nodes',row.entry).archived,'Старт должен быть действующим узлом этого сценария.');return{...row,version:old?old.version+(Object.keys(row).some(k=>row[k]!==old[k])?1:0):1};}
  if(key==='nodes'){
   const f=byId(state,'flows',row.flow);required(!f.archived,'Сценарий в архиве.');immutable(old,row,['flow'],'Узел сохраняет свой сценарий.');if(!old||Object.keys(row).some(k=>row[k]!==old[k]))f.version++;return row;
  }
  if(key==='edges'){
   const source=byId(state,'nodes',row.source),target=byId(state,'nodes',row.target),f=byId(state,'flows',source.flow);required(!f.archived&&!source.archived&&!target.archived&&source.flow===target.flow,'Нужны действующие узлы одного действующего сценария.');immutable(old,row,['source'],'Исходный узел неизменен. Архивируйте переход и создайте новый.');if(!old||Object.keys(row).some(k=>row[k]!==old[k]))f.version++;return{...row,flow:source.flow};
  }
  required(!old,'Сохранённая публикация или трасса неизменна. Создайте новую.');
  if(key==='releases'){const p=graphFor(state,row.flow);return{...row,...p,graphVersion:p.snapshot.flow.version,publishedBy:actor.name,publishedAt:new Date().toISOString()};}
  const release=currentRelease(state,row.release),result=walk(release.snapshot,row.choices,row.language,true);return{...row,snapshot:release.snapshot,releaseDigest:release.digest,graphVersion:release.graphVersion,trace:result.trace,outcome:result.outcome,performedBy:actor.name,performedAt:new Date().toISOString()};
 },
 validate(state,before,command){
  if(command.operation==='archive'&&['nodes','edges'].includes(command.collection)){const n=rows(state,command.collection).find(x=>x.id===command.id),old=changed(before,command.collection,command.id);if(old&&!old.archived)byId(state,'flows',n.flow).version++;}
  unique(rows(state,'flows'),'code','Код сценария');
  for(const f of rows(state,'flows')){required(positive(f.version),'Неверная версия сценария.');if(f.entry)required(byId(state,'nodes',f.entry).flow===f.id,'Старт из другого сценария.');unique(rows(state,'nodes').filter(n=>n.flow===f.id),'code','Код узла в сценарии');}
  for(const n of rows(state,'nodes'))byId(state,'flows',n.flow);
  for(const e of rows(state,'edges'))required(byId(state,'nodes',e.source).flow===e.flow&&byId(state,'nodes',e.target).flow===e.flow,'Переход связывает разные сценарии.');
  const versions=new Set();for(const r of rows(state,'releases')){
   const sourceFlow=byId(state,'flows',r.flow);required(r.graphVersion<=sourceFlow.version,'Публикация новее текущей истории сценария.');const report=analyse(r.snapshot),key=r.flow+':'+r.graphVersion;required(r.snapshot.flow.id===r.flow&&r.graphVersion===r.snapshot.flow.version&&hash(r.snapshot)===r.digest&&same(report,r.report),'Нарушен снимок публикации.');required(!versions.has(key),'Эта версия графа уже опубликована.');versions.add(key);for(const n of r.snapshot.nodes)required(byId(state,'nodes',n.id).flow===r.flow,'Потерян источник узла снимка.');for(const e of r.snapshot.edges)required(byId(state,'edges',e.id).flow===r.flow,'Потерян источник перехода снимка.');required(text(r.publishedBy)&&Number.isFinite(Date.parse(r.publishedAt)),'Неверная история публикации.');const old=changed(before,'releases',r.id);if(old)immutable(old,r,['flow','snapshot','digest','report','graphVersion','publishedBy','publishedAt']);
  }
  for(const r of rows(state,'rehearsals')){
   const release=byId(state,'releases',r.release),result=walk(r.snapshot,r.choices,r.language,true);required(r.releaseDigest===hash(r.snapshot)&&r.releaseDigest===release.digest&&same(r.snapshot,release.snapshot)&&r.graphVersion===r.snapshot.flow.version&&same(r.trace,result.trace)&&r.outcome===result.outcome,'Трасса не совпадает с опубликованным графом и путём.');required(text(r.performedBy)&&Number.isFinite(Date.parse(r.performedAt)),'Неверная история репетиции.');const old=changed(before,'rehearsals',r.id);if(old)immutable(old,r,['release','language','choices','snapshot','releaseDigest','graphVersion','trace','outcome','performedBy','performedAt']);
  }
 },
 summarize(state){return rows(state,'rehearsals').filter(r=>!r.archived).map(r=>summary(r.snapshot.flow.code+' · v'+r.graphVersion,r.language.toUpperCase()+' · '+r.trace.length+' узла',r.outcome==='handover'?'Модель: к сотруднику; реальной передачи нет.':'Модель завершена; внешних действий нет.'));}
};
