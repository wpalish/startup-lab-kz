---
version: 1
slug: "public-app-js"
primary_target: "public/app.js"
related_targets: ["public/styles.css","public/index.html"]
---

Scope: BekitChange public/app.js; Operate; synthetic directory changes by author and two named reviewers.
THESIS: Two saved approvals authorize only the exact base version; a newer target stays protected.
OWN-WORLD: Inherit own JinaqKit Shared Work Cabinet navy navigation, pale workspace, green actions, white native labelled forms and wrapping evidence. Narrow extension, no replacement world.
STORY: Author freezes old/new RU/KK text and two other accounts; first then second reviewer decides; author applies once only when target version still matches. Rejection closes the request.
FIRST VIEWPORT: Request status, base/target versions and actor; old/new content, two ordered named decisions, then only this account's action. Signature: approved request beside newer target version and explicit blocked application reason.
FORM: Code-led inherited extension. Native tables/forms/disclosures, visible focus and authored lang=ru/kk. No comp, new world, animation or seed roll needed.
FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance
