---
name: BekitChange
description: An inherited working cabinet for immutable bilingual change requests, ordered account decisions and explicit whole-text application.
colors:
  primary: "#126653"
  primary-hover: "#0b5343"
  navy: "#183e60"
  ink: "#172e45"
  page: "#edf3f8"
  surface: "#ffffff"
  line: "#b9cbd9"
  navigation-surface: "#dce9f3"
  muted: "#46627a"
  input-stroke: "#7894aa"
  link: "#174e7e"
  pending: "#795200"
  error: "#942721"
  error-surface: "#fff0ee"
  focus: "#bd671a"
  selection-surface: "#b7ded2"
  selection-ink: "#132f29"
typography:
  primary-heading:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
    fontSize: "2rem"
    lineHeight: 1.15
    letterSpacing: "-0.025em"
  section-heading:
    fontSize: "1.3rem"
  brand:
    fontSize: "1.4rem"
    fontWeight: 740
  body:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
  label:
    fontWeight: 600
  supporting:
    fontSize: "0.9rem"
  exact-json:
    fontSize: "0.85rem"
rounded:
  control: "7px"
  panel: "12px"
spacing:
  evidence-gap: "0.4rem"
  inline-gap: "0.5rem"
  action-gap: "0.6rem"
  control-inset: "0.7rem"
  table-cell: "0.9rem"
  unit: "1rem"
  page-inline: "1.25rem"
  panel-inset: "1.4rem"
  section: "2rem"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-default:
    backgroundColor: "{colors.navy}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "{spacing.control-inset}"
    width: "100%"
  panel:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
    padding: "{spacing.panel-inset}"
  navigation-current:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  record-table:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
    width: "100%"
  record-table-heading:
    backgroundColor: "{colors.navigation-surface}"
    textColor: "{colors.ink}"
    typography: "{typography.supporting}"
    padding: "{spacing.table-cell}"
  saved-state-disclosure:
    padding: "0.7rem 0"
---

# Design System: BekitChange

## Overview

**Creative North Star: "The Shared Work Cabinet"**

BekitChange extends the documented JinaqKit Shared Work Cabinet. It keeps navy identity and navigation, a pale blue workspace, white labelled forms and tables, green explicit actions, system typography and native controls. This is an inherited, code-led extension with no replacement visual world or approved image comp. The source lineage is [JinaqKit DESIGN.md at its documentation commit](https://github.com/wpalish/jinaq-kit/blob/0717b3f0a361c23c2f9a5bcda87f6106ba82fe28/DESIGN.md).

Its character is direct, flat and readable. A saved request leads with its written state, original/current versions, author, time and reason; complete original and proposed RU/KK text follows. Two named, ordered account decisions remain visible before the action available to this account. The signature is two saved approvals beside a newer target version and an explicit refusal to apply: an approval remains attached to its immutable snapshot, while the current card has a separate disclosure.

**Key Characteristics:**

- Inherited navy navigation and pale blue workspace.
- White bordered native forms and tables with green explicit actions.
- System typography, fixed-size task headings and readable paragraph measures.
- Complete original and proposed RU/KK text before decisions or application.
- Two distinct named reviewer accounts in an ordinary ordered list.
- Two approvals kept separate from one explicit whole-text application by the original author.
- Visible target-version conflict, final rejection and separate saved application identity.
- Native current-card and published-policy disclosures, wrapping evidence and visible focus.

## Colors

The inherited cool palette uses Cabinet Navy for orientation and Working Green for explicit actions. The frontmatter owns implemented values. Sidecar tonal strips are derived inspection metadata inherited from the same palette; they are not additional interface colors.

### Primary

- **Working Green** (`primary`, `primary-hover`): submit buttons and explicitly primary actions, including checking a snapshot, recording a decision and applying both texts. The inherited status utility also uses green; the request states themselves are written text.

### Secondary

- **Cabinet Navy** (`navy`): header, baseline filled buttons, navigation text and secondary-control borders.
- **Link Blue** (`link`): links and field carets.

### Tertiary

- **Pending Amber** (`pending`): retained pending utility; the actual request stage is expressed in words.
- **Error Red / Pale Error** (`error`, `error-surface`): refused-action notices and the blocked target-version application message.
- **Focus Amber** (`focus`): visible focus on fields, actions, scrolling tables and native disclosure summaries.
- **Soft Selection Green / Selection Ink** (`selection-surface`, `selection-ink`): native text selection.

### Neutral

- **Cabinet Ink** (`ink`): root text, headings and record values.
- **Cool Workspace** (`page`): page ground and scrollbar track.
- **White Surface** (`surface`): fields, form panels, tables, ordinary notices and current navigation.
- **Divider Blue** (`line`): panel/table outlines, rows and evidence dividers.
- **Navigation Mist** (`navigation-surface`): navigation strip and table headings.
- **Supporting Slate** (`muted`): local/synthetic boundaries, digest, helper copy and footer.
- **Field Slate** (`input-stroke`): field borders and scrollbar thumb.

**The Inherited Shell Rule.** Extend the existing JinaqKit cabinet palette, typography and navigation grammar.

## Typography

The recorded system stack serves headings, body and controls. No webfont is loaded. The main heading has the recorded fixed size and tracking; section headings are smaller and the brand has the recorded heavier weight. Unspecified body size, heading weights and line heights retain browser defaults. Preformatted settings data uses the native browser face at the recorded smaller size, rather than a separate display identity.

Paragraphs have maximum measure (72ch), line height (1.6) and ordinary margins. Labels and buttons use weight (600). Tables use tabular numerals and left/top alignment. Authored text preserves line breaks through `white-space: pre-wrap`. Written status, stage and result copy carries meaning independently of color.

The document language is Russian. Request editors explicitly mark the new RU and KK text fields with their language attributes; card/policy editors do the same for the authored body and instruction fields. `bodies` renders the saved original, proposed, current-card and policy text as separate `lang="ru"` and `lang="kk"` paragraphs. Interface labels, reasons and diagnostics remain Russian interface context; the application does not infer or translate authored language.

**The Authored Language Rule.** Preserve authored RU/KK language nodes and line breaks within the Russian interface.

## Layout

Header and navigation share inline padding (`max(1.25rem, calc((100% - 1160px) / 2))`). Main is centered with maximum width (1200px), padding (`2rem 1.25rem`) and minimum height (75vh). Header is a spaced flex row. Navigation and action rows use compact recorded gaps; actions wrap. The retained optional work grid has columns (`minmax(0, 1fr) minmax(260px, 0.8fr)`), while paired rows use equal columns. Request detail uses a vertical reading order on the page ground; white panels identify the currently available form.

The detail sequence is written status and original/current versions, author/time/reason, complete original text, complete proposed text, two named sequential decisions, the allowed review or application form or its refusal, any saved application identity, current-card disclosure, exact published-policy disclosure, digest, local boundary and refresh/return actions. A completed application does not replace the old or proposed text with the current card. Rejection leaves the saved decision visible and explicitly closes the later stage.

Source declares a stacked breakpoint (700px and below): optional grids stack, main padding becomes (`1.4rem 1rem`), panel padding becomes (1rem), navigation wraps with padding (0.6rem), and the header identity uses size (0.8rem) and maximum width (140px) while aligning to the top. At the narrow table/search breakpoint (600px and below), search tools stack, navigation buttons use `flex: auto`, table cells receive minimum width (140px) and a horizontal-scroll hint appears. A labelled focusable table wrapper owns scrolling. These are source-defined rules, not verified rendering at those widths.

Headings, header identity, evidence, native disclosures, direct screen paragraphs, diagnostic items and footer wrap long values. Evidence sections use a top border, unit top margin/padding and the recorded gap. Ordered decision content has inset (1.5rem). No fixed-height crop truncates authored text or the request digest.

The [finish review](docs/finish-review.json) records a bounded `ship` verdict for six valid actual 1280px captures. Five shipping JPEGs show [first-review form](docs/review-form-1280.jpg), [author application form](docs/apply-form-1280.jpg), [saved application](docs/applied-1280.jpg), [target-version conflict](docs/target-conflict-1280.jpg) and [final rejection](docs/rejected-1280.jpg). Their hashes and own synthetic browser origin are in [capture provenance](docs/capture-provenance.json). The sixth is workspace stale-command-refusal evidence enumerated in the finish review; it is not a shipping alias in the provenance list. This documentation pass opened all six as valid, nonblank images.

These are authentic earlier workflow states, not a claim about the current database or a way to reopen a completed immutable form. The rejected state was recaptured from current source after the final later-stage wording clarification; the other supplied render branches were unchanged by that small batch, which also propagated the asynchronous request-form error. The five shipping aliases preserve the reviewed bytes.

Only actual 1280px evidence supports the visual verdict. Mobile/390px and 1440px remain unverified. This documentation pass inspected source and images; it did not operate the browser, rerun context, the detector, interactions or backend tests. Other screens, every breakpoint, hover/loading/empty/overlong content, touch and screen-reader behavior remain outside this review. Neither source semantics nor this visual packet establishes backend correctness, account independence beyond distinct accounts, concurrency, restore, transport, security, real-data suitability or a service outcome.

## Elevation & Depth

No box shadow, backdrop effect, transition or animation is defined. Pale ground, white form/table surfaces, one-pixel borders and section spacing provide separation. Hover changes brightness and primary fill without motion. Replacing content and focusing a task or preview heading provides continuity. No decorative raster is used; the supplied JPEGs are evidence assets with explicit provenance and temporal limits.

## Shapes

Controls and notices use the smaller recorded radius; panels and table wrappers use the larger one. Borders are one pixel. Textareas start at height (100px) and resize vertically. Buttons and native disclosure summaries have minimum height (44px). Native disclosure markers remain visible. Named stages use an ordinary ordered list. Retained fieldset, recipient-choice and case-result rules do not define the request-detail composition.

## Components

### Buttons

Native labelled actions use padding (`0.65rem 1rem`) and the recorded label weight. Explicit primary and all submit buttons use Working Green with white text; hover combines the deeper primary fill with brightness (1.13). Secondary refresh, return, archive and settings actions use white with navy text and border. The retained baseline button rule is navy filled. Disabled buttons use opacity (0.55) and `cursor: not-allowed`. Focus-visible is an amber outline (3px) with offset (3px); source caps narrow buttons at width (100%). The initiating button is disabled while its asynchronous request runs.

### Cards / Containers

Flat white form panels use a Divider Blue border, the panel radius and recorded inset, reduced at the stacked breakpoint. Login is capped at width (480px). Saved request metadata, original/proposed text, decisions, application identity and native disclosures stay on the pale page ground. Preview evidence follows the form without a modal.

### Inputs / Fields

Native inputs, selects and textareas use White Surface, Cabinet Ink, Field Slate borders and Link Blue carets. Generated fields have connected labels and unique IDs. Required decisions and reasons keep native required semantics. Archived/role-protected generic editors preserve values through read-only fields or disabled selectors; configured bounds remain native input attributes.

Request creation uses selectors for card and published policy, required RU/KK textareas, a required reason and two labelled account selectors. The author is excluded from the account options; the product requires the two assigned accounts to differ. These are distinct accounts, not proof of independent people. The review form has a required decision selector and required **Основание решения** textarea. The author application form has required **Основание применения**. Failed commands preserve unsaved field values and selection; the focused error notice supplies the recovery instruction. A retained reason is not a recorded review or application.

### Navigation and Notices

The linked brand and current account/role lead the navy header. Inactive section buttons are transparent on the pale strip; the current collection is white bordered with `aria-current="page"`. Requests (`requests`) is the initial collection. The skip link becomes visible on focus. Task changes focus the leading heading using `tabindex="-1"`; successful previews focus their result heading. The shared notice has `role="status"`, `aria-live="polite"` and a programmatic focus target. Empty notices are hidden. Refusals use Pale Error and Error Red, while ordinary notices use White Surface. Source semantics and visible focus do not establish a complete keyboard or screen-reader audit.

### Publication and Immutable Request Preview

Policy preview uses a native selector and **Проверить порядок**, then renders the exact candidate code/version, title, both instructions and ordered stage names before **Опубликовать эту версию**. Selector changes clear the preview; a generation counter discards obsolete responses.

Request preview follows **Проверить снимок запроса** and says **Предпросмотр · пока не сохранено**. Complete old/new RU/KK text and named first/second accounts precede **Сохранить неизменный запрос**. Any input/change clears this result and invalidates pending responses. Saving the request explicitly says that the card has not changed. These preview patterns are source-defined; no preview capture was supplied for the bounded finish verdict.

**The Preview Boundary Rule.** Keep complete candidate evidence and the separate explicit save action together; a preview is not a saved request or a changed card.

### Saved Request and Ordered Decisions

Detail leads with **Ожидает первого решения**, **Ожидает второго решения**, **Два одобрения · ещё не применено**, **Отклонён окончательно** or **Применён к локальной карточке**. Original and current versions remain adjacent. **Исходное содержание · v…** and **Предложенное содержание** render all authored text, followed by **Два последовательных решения** in an ordered list. Each item names its saved policy stage and assigned account; saved decision, timestamp and reason replace the unrecorded message.

Only the currently assigned reviewer receives **Ваше решение · этап …**, the labelled approve/reject selector, required reason and **Записать решение этапа …**. Other accounts see who may decide and that an administrator does not bypass the assignment. First-stage rejection leaves the refusal and reason visible, says **Этап закрыт после отказа** for stage two and exposes no later decision/application form. The rejected shipping image records that current-source wording.

**The Ordered Account Rule.** Keep both named assignments and their saved decisions in order; final rejection explicitly closes the later stage.

### Explicit Application, Saved Application and Target Conflict

After both approvals, **Явное применение** appears. An unchanged active target offers the original author a white form saying that both new texts will be saved whole and that two decisions have not yet changed the card. **Применить оба текста один раз** follows the required application reason. Other accounts receive the original-author explanation. Admin has no visual bypass. The UI represents one explicit whole RU/KK application, not automatic, partial or repeated application.

After saving, the form is replaced by **Сохранённое применение #…**, exact before→after versions, actor, time and reason. The supplied applied state retains original v1, proposed text and both approvals while its current-card disclosure shows v2. A separate application identity is evidence of the recorded local operation; the preceding form and entered reason are only a before-submission state.

A competing source-v1 request retains both approvals when the target reaches v2. Its error text closes application, names the version change and instructs creating a new request from the current card because old approvals do not transfer. There is no apply form. An archived target has its own explicit refusal. Reviewable saved content is distinct from permission to apply it.

**The Exact Target Rule.** Keep two saved approvals visible beside any target-version conflict; do not offer application against a changed or archived target.

**The Explicit Whole Application Rule.** Keep the original-author reason and one-time whole-text action separate from two approvals; saved application identity replaces the form.

### Current Card, Saved Policy and Tables

**Текущая карточка · v…** is a native disclosure of the current RU/KK content. **Точный опубликованный порядок** separately renders the request's saved policy code/version, title, instructions and stage order. Both are closed by default. The request digest follows outside them; it is consistency evidence, not a signature. Card detail separately offers **Начальное содержание · v1**. Current-card content never overwrites saved request text or policy snapshots in the presentation.

Native list tables use collapsed borders, left/top aligned cells, padding (0.9rem), wrapping values, maximum cell width (28ch), tabular numerals and pale headings. Headers have column scope. The labelled focusable wrapper owns horizontal scrolling; each row has a labelled open action. Search, archive visibility and empty results retain native controls and explanatory text. Source-visible data/access controls do not establish settings, backup authenticity, tenant isolation or security verification.

**The Snapshot Separation Rule.** Keep original/proposed request text, exact saved policy and current card distinct, including after application.

Sources are [app.js](public/app.js), [styles.css](public/styles.css) and [index.html](public/index.html); durable task truth is in [PRODUCT.md](PRODUCT.md), and the six-block direction remains in [public-app-js.md](.impeccable/surfaces/public-app-js.md). [.impeccable/design.json](.impeccable/design.json) extends the frontmatter with inherited color metadata, focus/hover/breakpoint details and twelve self-contained static examples. Examples use synthetic text, native elements and non-submitting buttons; they contain no application handlers or backend execution.

## Do's and Don'ts

### Do:

- **Do** inherit the navy header, pale workspace, white native forms/tables and green explicit action.
- **Do** keep connected labels, column-scoped table headers, native disclosure markers and visible focus.
- **Do** preserve authored RU/KK language nodes, line breaks and complete text.
- **Do** keep original/current versions, old/new text and two named ordered decisions together.
- **Do** distinguish unsaved preview, saved request, two approvals and saved application.
- **Do** keep the original author's required reason and explicit one-time whole-text application.
- **Do** show target-version conflict and new-request recovery while preserving saved approvals.
- **Do** close the later stage explicitly after final rejection and remove unavailable action forms.
- **Do** keep saved request/policy snapshots separate from the current card disclosure.
- **Do** retain unsaved selection and reason with the stale-refusal recovery message.
- **Do** allow long authored text, account names, timestamps and SHA256 digests to wrap.

### Don't:

- **Don't** replace the inherited cabinet identity with ornamental assets or animation.
- **Don't** hide labels or replace native tables, ordered lists and disclosures with decorative imitations.
- **Don't** present a preview or retained draft reason as a saved decision or application.
- **Don't** conflate two approvals with automatic application or offer a partial/repeated application.
- **Don't** expose a reviewer, later stage, administrator or non-author bypass in the action area.
- **Don't** transfer old approvals to a new request or substitute current content for a saved snapshot.
- **Don't** leave the later stage looking pending after final rejection.
- **Don't** imply that distinct accounts prove independent people or correct authored text.
- **Don't** imply live Relay connectivity, external approval, messaging, contracts, payments or delivered service outcomes.
- **Don't** present a digest or bounded visual review as a signature or security certification.
- **Don't** claim 390px/mobile, 1440px, touch or screen-reader verification from the supplied 1280px evidence.
