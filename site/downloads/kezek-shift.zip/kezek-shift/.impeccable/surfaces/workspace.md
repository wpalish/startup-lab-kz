# Workspace

Mode: Operate. Code-led local extension of JolFlow/HabarPrep, no new visual world or approved comp. DESIGN.md and its schema-v2 sidecar document the inherited system.

## Direction contract

THESIS: Make the selected ticket, queue eligibility and remaining capacity inspectable before an explicit claim, then preserve the decision as history.
OWN-WORLD: Inherited navy identity/navigation, pale blue workspace, white labelled forms, green primary action, system type, thin borders and native disclosure.
STORY: Register waiting requests;configure account availability/capacity;check own queue;claim the deterministic next ticket;complete with basis;read immutable assignment evidence.
FIRST VIEWPORT: Identity/nav and current task title. Queue check shows account/queue/language/load/capacity and selected priority before claim. Assignment history shows exact chosen context and rule;completion does not rewrite the decision.
FORM: Native selectors and list/editor cabinet. seed:none(local extension). Signature interaction: a claim recomputes priority/language/capacity atomically;stale preview or repeated request key never takes another ticket.
QUALITY BAR: Clear manual/synthetic scope;no document overflow at1440/1280/390;preserved form on refusal;native disclosure;focus after async decisions;RU/KK content language separate from Russian interface;explicit completion with basis.
FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance

## Finish record

- Review verdict: **ship**, with no material fixes in [the finish review](../../../../program/kezek-shift-finish-review.json).
- Documentation checked PRODUCT.md, README.md, public/app.js, public/styles.css, public/index.html, the incumbent JolFlow DESIGN.md/sidecar and all five required supplied captures: assignment at 1440/1280/390 and preview at 1440/390. History includes expanded native rank disclosure and the owner's completion form; preview shows selected ticket and capacity before explicit claim.
- Scope: captured UI and source documentation. Tests, database/restart behavior and refusal evidence remain supplied review evidence; this pass did not rerun them. The verdict is not full security, accessibility, mobile/touch or production certification.
- Preserve: non-reserving eligibility preview; deterministic priority 5→1, earlier createdAt, then ascending ID; language and per-queue capacity; explicit claim; immutable historical decision; separate owner completion with basis; native wrapping, disclosure, focus and language semantics.
- Rasters: no shipping raster assets. Supplied review PNGs are evidence captures, not runtime imagery.
