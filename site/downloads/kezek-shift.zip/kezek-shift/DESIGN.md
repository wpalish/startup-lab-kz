---
name: KezekShift
description: An inherited working cabinet for queue eligibility, explicit deterministic claim, and inspectable assignment history.
colors:
  primary: "#126653"
  primary-hover: "#0b5343"
  navy: "#183e60"
  ink: "#172e45"
  page: "#edf3f8"
  surface: "#ffffff"
  line: "#b9cbd9"
  navigation-surface: "#dce9f3"
  muted: "#46627a"
  input-stroke: "#7894aa"
  link: "#174e7e"
  pending: "#795200"
  error: "#942721"
  error-surface: "#fff0ee"
  focus: "#bd671a"
  selection-surface: "#b7ded2"
  selection-ink: "#132f29"
typography:
  primary-heading:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
    fontSize: "2rem"
    lineHeight: 1.15
    letterSpacing: "-0.025em"
  section-heading:
    fontSize: "1.3rem"
  brand:
    fontSize: "1.4rem"
    fontWeight: 740
  body:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
  label:
    fontWeight: 600
  supporting:
    fontSize: "0.9rem"
rounded:
  control: "7px"
  panel: "12px"
spacing:
  inline-gap: "0.5rem"
  action-gap: "0.6rem"
  control-inset: "0.7rem"
  unit: "1rem"
  page-inline: "1.25rem"
  panel-inset: "1.4rem"
  section: "2rem"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-default:
    backgroundColor: "{colors.navy}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "{spacing.control-inset}"
    width: "100%"
  panel:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
    padding: "{spacing.panel-inset}"
  navigation-current:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
---

# Design System: KezekShift

## Overview

**Creative North Star: "The Shared Work Cabinet"**

KezekShift extends the documented JolFlow / HabarPrep / StartupLab Operate cabinet. It keeps the navy identity and navigation, pale blue workspace, white labelled forms, green explicit actions, system typography, and native controls. The incumbent system remains the visual authority.

Its character is direct, flat, and readable. The selected request, language, queue and occupied capacity precede an explicit claim. The saved decision reuses that evidence grammar, while a separate owner completion form preserves the distinction between historical selection and later manual status.

**Key Characteristics:**

- Inherited navy navigation and pale blue workspace.
- Green labelled actions and white bordered form panels.
- System typography with a fixed-size primary heading.
- Native ranked disclosure, wrapping authored text, and deliberate task focus.
- Visible eligibility and capacity before claim; immutable decision evidence before separate completion.

## Colors

The cool inherited palette uses navy for orientation and Working Green for explicit actions. The frontmatter owns the implemented values; no new palette or tonal ramp is introduced.

### Primary

- **Working Green** (`primary`, `primary-hover`): submit and explicit claim actions; the inherited status utility uses the same green.

### Secondary

- **Cabinet Navy** (`navy`): header, default filled controls, navigation text and secondary borders.
- **Link Blue** (`link`): links and field carets.

### Tertiary

- **Pending Amber** (`pending`): inherited pending utility.
- **Error Red / Pale Error** (`error`, `error-surface`): refusal notice.
- **Focus Amber** (`focus`): visible keyboard and programmatic focus outline.
- **Soft Selection Green / Selection Ink** (`selection-surface`, `selection-ink`): native text selection.

### Neutral

- **Cabinet Ink** (`ink`): root text.
- **Cool Workspace** (`page`): page ground and scrollbar track.
- **White Surface** (`surface`): forms, notices and current navigation.
- **Divider Blue** (`line`): containers, tables and evidence dividers.
- **Navigation Mist** (`navigation-surface`): navigation strip and table headings.
- **Supporting Slate** (`muted`): helper copy and footer.
- **Field Slate** (`input-stroke`): field borders and scrollbar thumb.

**The Inherited Shell Rule.** Extend the current JolFlow / HabarPrep / StartupLab cabinet instead of replacing its palette, typography, or navigation grammar.

## Typography

The system stack in the frontmatter serves headings, body and controls. No webfont is loaded; unspecified sizes and weights retain browser defaults. Primary headings are fixed-size, section headings use the smaller recorded scale, and brand text uses the recorded heavier weight.

Paragraphs have a maximum measure of 72ch and line height 1.6. Labels and buttons use weight 600; supporting text uses the smaller recorded size. Evidence preserves context line breaks. Audit text wraps anywhere at 0.85rem; table and date values use tabular numerals. The root body size and line height are not explicitly declared.

The Russian interface inherits `lang="ru"`. Ticket title/context edit fields, table titles, selected context and ranked titles carry the authored `ru` or `kk` language. Status, capacity and ordering explanations remain Russian. The manual completion basis inherits Russian interface semantics; its form has no language selector.

**The Authored Language Rule.** Preserve the actual RU or KK language on authored ticket text without changing the surrounding Russian interface language or inventing a translation.

## Layout

Header and navigation share `max(1.25rem, calc((100% - 1160px) / 2))` inline padding. Main is centered with maximum width 1200px, `2rem 1.25rem` padding and minimum height 75vh. The header uses a spaced flex row; navigation has a 0.5rem gap. The inherited optional work grid has `minmax(0, 1fr) minmax(260px, 0.8fr)` columns and 2rem gap; paired rows use equal columns and 1rem gap. Current preview and assignment screens follow a vertical reading order.

At 700px and below, grids stack, main padding becomes `1.4rem 1rem`, panels use 1rem padding, and navigation wraps with 0.6rem padding. Identity aligns to the top, uses 0.8rem text and maximum width 140px. At 600px and below, navigation buttons use `flex: auto`, search tools stack, and table cells have minimum width 140px with 0.9rem table type. Table scrolling belongs to its focusable wrapper, accompanied by a narrow-screen hint.

Action rows wrap. Headings, identity, disclosures, evidence and footer use `min-width: 0` and wrapping rather than truncation. Preview evidence has a top divider, 1rem top padding/margin and 0.4rem grid gap; its direct claim button fills the grid width. History renders the same decision directly on the page, followed by the separate completion panel. The opened 1440/1280/390 assignment and 1440/390 preview captures document these states; they do not establish full mobile or touch coverage.

## Elevation & Depth

No box shadow, backdrop effect, transition or animation is defined. White panels, pale fills, one-pixel borders and whitespace separate regions. Hover changes brightness and the primary fill without motion. Replacing screen content and focusing the task or preview heading provides interaction continuity without an animation system. No shipping raster imagery is used.

## Shapes

Controls and notices use the smaller recorded radius; panels and table wrappers use the larger one. Borders are one pixel. Textareas start at 100px height and resize vertically. Buttons and native disclosure summaries have minimum height 44px. The ranked list keeps the browser's disclosure marker and ordinary ordered-list indentation.

## Components

### Buttons

Native labelled actions use `0.65rem 1rem` padding and weight 600. Primary and submit actions use Working Green with white text; hover combines the deeper primary fill with brightness 1.13. Secondary actions use white, navy text and border. Default controls use navy fill. Disabled buttons use opacity 0.55 and `cursor: not-allowed`. Focus is a 3px amber outline with 3px offset; narrow buttons have maximum width 100%.

### Cards / Containers

White form panels use a Divider Blue border, panel radius and 1.4rem padding, reduced at the narrow breakpoint. Login is capped at 480px. Decision evidence uses the page ground and a divider instead of another card. Completion is a distinct labelled white form panel after historical evidence.

### Inputs / Fields

Native inputs, selectors and textareas use white fill, Cabinet Ink, Field Slate borders and Link Blue carets. Labels connect to generated field IDs. Protected records use native read-only/disabled fields. Failed submissions keep the form and show the error in the focused polite status notice above the screen.

### Navigation

The linked brand and user/role lead the navy header. Inactive controls are transparent on the pale strip; the current section is white with a border and `aria-current="page"`. Navigation wraps. The skip link becomes visible on focus; task changes focus a heading with `tabindex="-1"`.

### Eligibility Preview and Ranked Decision

A white queue selector and **Проверить очередь** precede the result. The leading copy states that preview reserves neither ticket nor capacity. The result shows the selected code/priority, authored title/context, account/queue/language, occupied count and that queue's capacity. A visible explanation states priority 5→1, earlier creation, then smaller ID. Native **Подходящие заявки в порядке выбора** disclosure contains the ordered candidates with priority, timestamp, ID and authored title.

Successful preview focuses its result heading. Changing the queue clears evidence; a generation guard ignores an obsolete response. **Забрать следующую заявку** follows the evidence and submits the preview revision/request key. The server rechecks selection atomically; the preview is not a reservation or proof of reading. These behaviors are documented from source and the finish record, not independently rerun during documentation.

**The Inspectable Claim Rule.** Keep selected context, eligibility, queue capacity, ordering explanation and native ranked disclosure visible before the explicit claim action.

### Immutable Assignment and Owner Completion

Assignment detail leads with selected code, manual status, claimant and timestamp. The unchanged historical decision repeats the same selected context, account/queue/language, load-before/capacity and ordered disclosure. Later queue, availability or waiting-ticket edits do not rewrite this evidence.

Only an active assignment's owner sees the required completion-basis textarea and **Завершить вручную**. Other viewers see who can complete it. Completed detail adds a separate completion heading, actor/time, basis and internal-status limitation. Completion releases capacity while preserving the original decision; it does not prove a real service occurred.

**The Historical Decision Rule.** Keep the immutable selection evidence separate from the later owner's manual completion record.

### Tables and Notices

Native full-width tables use collapsed borders, left/top aligned cells, 0.9rem padding, wrapping values, maximum cell width 28ch and pale header cells. Action text stays unbroken; the wrapper owns scrolling and visible focus. The last row removes its bottom divider. Refusals use pale red fill, error text and the focused `role="status"` / polite live notice. Ordinary notices use white fill.

## Do's and Don'ts

### Do:

- **Do** inherit the navy header, pale workspace, white form surfaces and green primary action.
- **Do** keep native controls, ranked disclosure markers and visible focus.
- **Do** preserve authored RU/KK ticket semantics within Russian interface copy.
- **Do** allow long context, timestamps and IDs to wrap.
- **Do** show the selected request and queue capacity before explicit claim.
- **Do** separate immutable decision evidence from owner completion and its manual basis.

### Don't:

- **Don't** replace the inherited cabinet with a new visual identity.
- **Don't** clip historical evidence or remove the native ranked disclosure marker.
- **Don't** imply that preview reserves a request, capacity or a place in a queue.
- **Don't** imply manual availability or completion proves presence, service or an external message.
- **Don't** overwrite the historical decision with current queue or availability values.
