import {createHash,randomUUID} from 'node:crypto';
import {F,S,R,C,rows,byId,required,changed,immutable,unique,summary} from './core/rules.js';

const positive=n=>Number.isSafeInteger(n)&&n>0;
const account=n=>typeof n==='string'&&/^[a-zA-Z0-9_.-]{3,80}$/.test(n);
const uuid=n=>typeof n==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(n);
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const hash=s=>createHash('sha256').update(JSON.stringify(s)).digest('hex');
const pick=(s,fields)=>Object.fromEntries(fields.map(k=>[k,s[k]]));
const ticketFields=['code','title','queue','language','priority','context'];
const snapshot=t=>pick(t,['id',...ticketFields,'stage','version','createdAt']);
export const priorityOrder=(a,b)=>b.priority-a.priority||Date.parse(a.createdAt)-Date.parse(b.createdAt)||(a.id<b.id?-1:a.id>b.id?1:0);
const allows=(roster,language)=>roster.language==='both'||roster.language===language;
const occupied=(state,id)=>rows(state,'assignments').filter(a=>a.roster===id&&a.status==='active').length;
const rule='priority5-desc_createdAt-asc_id-asc';

export function nextDecision(state,queueId,actor){
 const queue=byId(state,'queues',queueId);
 required(!queue.archived,'Очередь в архиве. Новые назначения закрыты.');
 const roster=rows(state,'rosters').find(r=>!r.archived&&r.queue===queueId&&r.account===actor.name);
 required(roster,'Для вашего аккаунта нет действующей записи доступности в этой очереди.');
 required(roster.availability==='on','Ваша доступность выключена. Новые назначения закрыты.');
 const loadBefore=occupied(state,roster.id);
 required(loadBefore<roster.capacity,'Вместимость в этой очереди исчерпана. Завершите назначение или обратитесь к администратору.');
 const eligible=rows(state,'tickets').filter(t=>!t.archived&&t.stage==='waiting'&&t.queue===queueId&&allows(roster,t.language)).map(snapshot).sort(priorityOrder);
 required(eligible.length>0,'Подходящих ожидающих заявок нет. Проверьте очередь и язык.');
 return {queue:pick(queue,['id','code','title']),roster:pick(roster,['id','account','queue','language','capacity','availability']),loadBefore,eligible,chosen:eligible[0].id,rule};
}

export default {
 slug:'kezek-shift',reference:7,title:'KezekShift',
 description:'Ручная диспетчерская: язык и вместимость → следующая заявка по приоритету → неизменный снимок назначения.',
 limitations:'Общая область · Доступность и завершение ручные · Без импорта, AI, перевода и внешних сообщений',
 collections:[
  C('queues','Очереди',[F('code','Код очереди'),F('title','Название')],{writeRole:'admin',labelField:'code',addLabel:'Создать очередь',description:'Очередь — категория общей области, не изоляция клиентов. Архив закрывает новые назначения, прежние можно завершить.'}),
  C('rosters','Доступность',[F('account','Аккаунт','staff',{readOnly:true}),R('queue','Очередь','queues',{readOnly:true}),S('language','Язык допуска',[['ru','RU'],['kk','KK'],['both','RU и KK']],{default:'ru'}),F('capacity','Мест в этой очереди','integer',{min:1,max:20}),S('availability','Доступность по записи',[['on','Доступен'],['off','Выключена']],{default:'off'})],{writeRole:'admin',addLabel:'Добавить доступность',description:'Ручная доступность существующего аккаунта, не расписание и не доказательство присутствия. Вместимость относится к этой очереди.'}),
  C('tickets','Заявки',[F('code','Номер заявки'),F('title','Тема'),R('queue','Очередь','queues'),S('language','Язык контекста',[['ru','RU'],['kk','KK']],{default:'ru'}),F('priority','Приоритет 1–5 (5 первый)','integer',{min:1,max:5}),F('context','Авторский контекст','textarea')],{labelField:'code',addLabel:'Зарегистрировать заявку',description:'Только разрешённые синтетические примеры, без контактов. Ожидающий текст можно исправить; после назначения он защищён.'}),
  C('assignments','Назначения',[R('queue','Очередь','queues',{readOnly:true}),S('status','Состояние',[['active','В работе'],['completed','Завершено вручную']],{default:'active'}),F('note','Основание завершения','textarea',{required:false}),F('requestKey','Ключ запроса','text',{readOnly:true})],{addLabel:'Проверить мою очередь',description:'Система выбирает подходящую заявку: 5→1, более ранняя, затем меньший ID. Забрать и завершить может только сам назначаемый сотрудник.'})
 ],
 preview(state,input,actor){required(input.mode==='dispatch','Неизвестная проверка.');return {decision:nextDecision(state,input.queue,actor),requestKey:randomUUID()};},
 normalizeRow(key,row,state,old,actor){
  if(key==='queues')return row;
  if(key==='rosters'){
   required(account(row.account),'Неверный аккаунт.');
   required(!byId(state,'queues',row.queue).archived,'Для новой или изменяемой доступности нужна действующая очередь.');
   immutable(old,row,['account','queue'],'Аккаунт и очередь записи доступности неизменны. Архивируйте свободную запись и создайте новую.');
   return row;
  }
  if(key==='tickets'){
   if(!old||row.queue!==old.queue)required(!byId(state,'queues',row.queue).archived,'Новая или изменённая ссылка требует действующей очереди.');
   required(!old||old.stage==='waiting','Назначенная заявка неизменна. Завершение доступно в её назначении.');
   return {...row,stage:'waiting',version:old?old.version+(ticketFields.some(k=>row[k]!==old[k])?1:0):1};
  }
  if(!old){
   required(row.status==='active'&&row.note==='','Новое назначение создаётся без завершения и основания.');
   required(uuid(row.requestKey),'Нужен новый ключ запроса. Проверьте очередь заново.');
   required(!rows(state,'assignments').some(a=>a.requestKey===row.requestKey),'Этот ключ запроса уже использован. Повтор не забирает следующую заявку.');
   const decision=nextDecision(state,row.queue,actor),ticket=byId(state,'tickets',decision.chosen),roster=decision.roster.id;
   ticket.stage='active';ticket.version++;ticket.updatedAt=new Date().toISOString();
   return {...row,ticket:ticket.id,roster,claimant:actor.name,decision,digest:hash(decision),completion:null};
  }
  required(old.status==='active','Завершённое назначение неизменно.');
  immutable(old,row,['queue','requestKey'],'Очередь и ключ назначения неизменны.');
  required(actor.name===old.claimant,'Завершает только назначенный сотрудник.');
  required(row.status==='completed'&&row.note.length>0,'Выберите ручное завершение и укажите основание.');
  const ticket=byId(state,'tickets',old.ticket);ticket.stage='completed';ticket.version++;ticket.updatedAt=new Date().toISOString();
  return {...row,ticket:old.ticket,roster:old.roster,claimant:old.claimant,decision:old.decision,digest:old.digest,completion:{by:actor.name,at:new Date().toISOString(),note:row.note}};
 },
 validate(state,before,command){
  unique(rows(state,'queues'),'code','Код очереди');unique(rows(state,'tickets'),'code','Номер заявки');
  unique(rows(state,'assignments'),'requestKey','Ключ запроса');unique(rows(state,'assignments'),'ticket','Назначенная заявка');
  const liveRosterKeys=new Set();
  for(const r of rows(state,'rosters')){
   byId(state,'queues',r.queue);required(account(r.account)&&Number.isInteger(r.capacity)&&r.capacity>=1&&r.capacity<=20&&['ru','kk','both'].includes(r.language)&&['on','off'].includes(r.availability),'Неверный аккаунт или параметры доступности.');
   const load=occupied(state,r.id);required(load<=r.capacity,'Нельзя уменьшить вместимость ниже текущей занятости.');
   if(r.archived)required(load===0,'Сначала завершите активные назначения этой записи доступности.');
   else {const key=r.account+':'+r.queue;required(!liveRosterKeys.has(key),'У аккаунта уже есть действующая запись в этой очереди.');liveRosterKeys.add(key);}
  }
  for(const a of rows(state,'assignments')){
   const queue=byId(state,'queues',a.queue),roster=byId(state,'rosters',a.roster),ticket=byId(state,'tickets',a.ticket),d=a.decision;
   required(account(a.claimant)&&uuid(a.requestKey)&&d&&hash(d)===a.digest&&d.rule===rule,'Неверный снимок назначения.');
   required(d.queue.id===queue.id&&d.roster.id===roster.id&&d.roster.queue===queue.id&&d.roster.account===a.claimant&&roster.account===a.claimant&&roster.queue===queue.id&&d.roster.availability==='on'&&['ru','kk','both'].includes(d.roster.language),'Неверный снимок очереди или доступности.');
   required(typeof d.queue.code==='string'&&d.queue.code.length>0&&typeof d.queue.title==='string'&&d.queue.title.length>0,'Неполный снимок очереди.');
   required(positive(d.roster.capacity)&&d.roster.capacity<=20&&Number.isSafeInteger(d.loadBefore)&&d.loadBefore>=0&&d.loadBefore<d.roster.capacity,'Неверная занятость в снимке.');
   required(Array.isArray(d.eligible)&&d.eligible.length>0&&d.eligible.length<=10000&&same([...d.eligible].sort(priorityOrder),d.eligible)&&d.chosen===a.ticket&&d.eligible[0].id===a.ticket,'Нарушен порядок выбора заявки.');
   const ids=new Set();for(const t of d.eligible){byId(state,'tickets',t.id);required(uuid(t.id)&&!ids.has(t.id)&&t.queue===a.queue&&t.stage==='waiting'&&positive(t.version)&&Number.isFinite(Date.parse(t.createdAt))&&['ru','kk'].includes(t.language)&&allows(d.roster,t.language)&&Number.isInteger(t.priority)&&t.priority>=1&&t.priority<=5&&['code','title','context'].every(k=>typeof t[k]==='string'&&t[k].trim().length>0),'Неверная подходящая заявка снимка.');ids.add(t.id);}
   const selected=d.eligible[0];required(ticketFields.every(k=>ticket[k]===selected[k])&&ticket.version===selected.version+(a.status==='completed'?2:1),'Назначенная заявка не совпадает с зафиксированным контекстом.');
   required(a.status==='completed'?a.completion&&a.completion.by===a.claimant&&a.completion.note===a.note&&a.note.length>0&&Number.isFinite(Date.parse(a.completion.at)):a.status==='active'&&a.completion===null&&a.note===''&&!a.archived,'Неверное завершение или архив активного назначения.');
   const old=changed(before,'assignments',a.id);if(old)immutable(old,a,['ticket','roster','claimant','decision','digest','queue','requestKey']);
   if(old&&command.operation==='archive')immutable(old,a,['status','note','completion']);
  }
  for(const t of rows(state,'tickets')){
   byId(state,'queues',t.queue);required(positive(t.version)&&Number.isInteger(t.priority)&&t.priority>=1&&t.priority<=5&&['ru','kk'].includes(t.language),'Неверная версия,приоритет или язык заявки.');
   const a=rows(state,'assignments').find(a=>a.ticket===t.id);
   required(t.stage===(a?(a.status==='active'?'active':'completed'):'waiting'),'Состояние заявки не совпадает с назначением.');
   if(t.archived)required(t.stage!=='active','Сначала завершите активное назначение заявки.');
  }
 },
 summarize(state){return rows(state,'rosters').filter(r=>!r.archived).map(r=>summary(r.account+' · '+byId(state,'queues',r.queue).code,'Занято '+occupied(state,r.id)+' из '+r.capacity,r.availability==='on'?'Доступность включена вручную; язык '+r.language.toUpperCase():'Доступность выключена; прежние назначения можно завершить.'));}
};
