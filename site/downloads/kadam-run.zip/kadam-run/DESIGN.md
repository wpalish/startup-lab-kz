---
name: KadamRun
description: The inherited working cabinet for frozen bilingual recipes, explicit text steps and preserved retry checkpoints.
colors:
  primary: "#126653"
  primary-hover: "#0b5343"
  navy: "#183e60"
  ink: "#172e45"
  page: "#edf3f8"
  surface: "#ffffff"
  line: "#b9cbd9"
  navigation-surface: "#dce9f3"
  muted: "#46627a"
  input-stroke: "#7894aa"
  link: "#174e7e"
  pending: "#795200"
  error: "#942721"
  error-surface: "#fff0ee"
  focus: "#bd671a"
  selection-surface: "#b7ded2"
  selection-ink: "#132f29"
typography:
  primary-heading:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
    fontSize: "2rem"
    lineHeight: 1.15
    letterSpacing: "-0.025em"
  section-heading:
    fontSize: "1.3rem"
  brand:
    fontSize: "1.4rem"
    fontWeight: 740
  body:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
  label:
    fontWeight: 600
  supporting:
    fontSize: "0.9rem"
  preformatted:
    fontSize: "0.85rem"
rounded:
  control: "7px"
  panel: "12px"
spacing:
  evidence-gap: "0.4rem"
  inline-gap: "0.5rem"
  action-gap: "0.6rem"
  control-inset: "0.7rem"
  table-cell: "0.9rem"
  unit: "1rem"
  page-inline: "1.25rem"
  panel-inset: "1.4rem"
  section: "2rem"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-default:
    backgroundColor: "{colors.navy}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "{spacing.control-inset}"
    width: "100%"
  panel:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
    padding: "{spacing.panel-inset}"
  navigation-current:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  record-table:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
    width: "100%"
  snapshot-disclosure:
    padding: "0.7rem 0"
  error-notice:
    backgroundColor: "{colors.error-surface}"
    textColor: "{colors.error}"
    rounded: "{rounded.control}"
    padding: "{spacing.unit}"
---

# Design System: KadamRun

## Overview

**Creative North Star: "The Shared Work Cabinet"**

KadamRun extends the project's own QaitaCycle Shared Work Cabinet: navy identity and navigation, a pale blue workspace, white labelled native forms, green explicit actions and system typography. The inherited visual authority is the [QaitaCycle design system](../qaita-cycle/DESIGN.md) and [sidecar](../qaita-cycle/.impeccable/design.json), supplied as owned source at commit `1858b593c2fabe82ecfa11bbf1695f36e2642ac8`. That is an owned Git commit, not a digest of DESIGN.md. The settled inherited direction supplies the qualitative language for this scan; no replacement visual world or image comp is introduced.

Its character is flat, direct and readable. The job begins with its owner, written state and saved-step count, then exposes the frozen bilingual recipe, original input and latest saved text. An unsaved preview precedes each explicit command, while native disclosures hold the ordered saved trace. A server-time threshold permits a later owner action; it does not act or prove real work.

**Key Characteristics:**

- Inherited navy shell, cool workspace and flat white native controls.
- Restrained system type, connected labels and tabular record lists.
- Frozen authored RU/KK recipe and real step positions remain inspectable.
- Original input, saved checkpoint text, unsaved preview and saved trace stay distinct.
- Explicit owner actions, written refusals and separately retained unsaved input.

## Colors

The frontmatter owns the implemented values extracted from [the stylesheet](public/styles.css#L1). Descriptive color names and derived inspection ramps continue the identical inherited palette. Sidecar ramps are metadata, not additional implemented interface colors.

### Primary

- **Working Green / Deep Working Green** (`primary`, `primary-hover`): explicit primary and submit actions, including preview, publication, job creation and single-action save. The fill identifies an available action; the label identifies its effect.

### Secondary

- **Cabinet Navy** (`navy`): identity header, baseline filled buttons, secondary borders and navigation text.
- **Link Blue** (`link`): ordinary links and native field carets.

### Tertiary

- **Pending Amber** (`pending`): the written retry-eligibility explanation.
- **Error Red / Pale Error** (`error`, `error-surface`): refused-request notice with a focused written explanation.
- **Focus Amber** (`focus`): visible focus outline on controls, headings and disclosures.
- **Soft Selection Green / Selection Ink** (`selection-surface`, `selection-ink`): native selected text.

### Neutral

- **Cabinet Ink** (`ink`): reading text and authored instructions.
- **Cool Workspace / White Surface** (`page`, `surface`): page ground and native fields, panels, notices and tables.
- **Divider Blue / Navigation Mist** (`line`, `navigation-surface`): one-pixel boundaries, navigation ground and table headers.
- **Supporting Slate / Field Slate** (`muted`, `input-stroke`): helpers/footer and field strokes/scrollbars.

**The Inherited Shell Rule.** Extend the existing Shared Work Cabinet palette, type and native control grammar.

## Typography

One system stack serves body, headings and controls; no font asset is loaded. The task heading, smaller section heading, heavier brand and connected label roles are normative in frontmatter. Unspecified body size and heading weights retain browser defaults. Paragraphs have maximum measure (72ch) and line height (1.6). Tables use tabular numerals. Before/after text and audit JSON use native preformatted text with the smaller `preformatted` role, preserved line breaks and wrapping. Source: [type](public/styles.css#L63), [fields](public/styles.css#L91), [preformatted text](public/styles.css#L235), [tables](public/styles.css#L298).

The shell language is Russian. Authored instructions use separate RU and KK nodes with `lang` attributes; instruction paragraphs preserve visible line breaks. Raw timestamps and digests remain exact text. Long headings, evidence and details wrap rather than clip. Source: [authored helper](public/app.js#L4), [snapshot](public/app.js#L29), [result text](public/app.js#L33).

**The Authored Text Rule.** Preserve authored RU/KK text, language nodes and visible line breaks; do not silently rewrite a frozen instruction or saved rationale.

## Layout

Header and navigation share inline padding (`max(1.25rem, calc((100% - 1160px) / 2))`). Main is centered at maximum width (1200px), padding (`2rem 1.25rem`) and minimum height (75vh). Navigation wraps at every width. Peer actions use a wrapping flex row with the recorded action gap. Search and archive visibility precede a native record table. White panels hold connected fields. Optional two-column work and paired-row grids remain in inherited CSS; the current job detail and owner form are single-column. Source: [shell and grids](public/styles.css#L26), [actions](public/styles.css#L144), [search and tables](public/styles.css#L290), [navigation wrapping](public/styles.css#L417).

The job-detail order is title → owner/written state → saved-step and event counts → creation time and optional retry time → native exact-recipe disclosure → original input → latest saved text → eligible owner form and unsaved preview, or written owner-only explanation → any separate retained-input panel → ordered trace → wrapping refresh/return actions. Terminal jobs have no owner action form. The original input and current saved value are separate reading blocks. Source: [job detail](public/app.js#L34).

At the source-defined stacked breakpoint (700px), optional grids become one column, page/panel insets reduce, header identity narrows and button/navigation sizing adapts. At (600px), search stacks, table cells gain minimum width (140px) and table type reduces. The inherited scroll-hint class is defined but is not inserted by the current record renderer. Labelled focusable table wrappers own horizontal overflow. These are source-defined rules, not verified mobile behavior. Source: [responsive rules](public/styles.css#L258), [current table renderer](public/app.js#L26).

### Evidence scope and freshness

The [fresh finish review](docs/finish-review.json) returned **ship** with no material findings for all nine supplied current-source owner job-detail captures at actual width (1280 CSS px), plus the named current source. This is a fresh review of that packet, not the inherited Qaita F1-only verdict. The reviewer opened all nine valid nonblank full-page JPEGs and found no visible overlap or clipping. The documenter checked their SHA-256 values and all six source hashes against the review; every value matches. The documenter did not open a browser, repeat interactions or rerun the detector.

Actual CSS width and scroll width (1280) are builder-supplied observations, not independently repeated here. A prior viewport capability setting did not change the DOM width and supplies no mobile evidence. Raster dimensions below are recorded by the review.

| Review capture | Raster dimensions | SHA-256 |
| --- | --- | --- |
| [waiting-after-restart-1280](.impeccable/review/waiting-after-restart-1280.jpg) | 1280 × 1303 | `9c7f123d1d450247e37fe4a9923a1bfb1438ef41a4c07db9f1d173200020c19f` |
| [exhaustion-preview-1280](.impeccable/review/exhaustion-preview-1280.jpg) | 1280 × 1718 | `00a8f067b158b6a0b0bc458fcf6721f16627c89bc4e49811dd596740e1e836f6` |
| [exhausted-1280](.impeccable/review/exhausted-1280.jpg) | 1280 × 953 | `28d9b081c0b4c20ef538787aa8c4c5b27aa3bdaa692caa9ce2cd04e075696d56` |
| [stale-cancel-1280](.impeccable/review/stale-cancel-1280.jpg) | 1280 × 1645 | `356f97e97ad5f896e8c8682814e2a6b73b81e9e28334f28fc576d0af52423091` |
| [refreshed-cancel-form-1280](.impeccable/review/refreshed-cancel-form-1280.jpg) | 1280 × 1059 | `e26b45c02e3da79390c36a57629b7afa74d2964e3befa082d3bb34bca901e24f` |
| [cancelled-1280](.impeccable/review/cancelled-1280.jpg) | 1280 × 893 | `84c4ad462f502edcbe71f6a06792de0cc373cb7d66c277f6f419599b39cc69b1` |
| [retry-preview-1280](.impeccable/review/retry-preview-1280.jpg) | 1280 × 1820 | `4485c46f0035639bfeb052a41789e10fc86e6d8b933bb5fa6206463365926a2e` |
| [completed-recipe-1280](.impeccable/review/completed-recipe-1280.jpg) | 1280 × 1479 | `a2d9059ff17e243ea18cfe3ff5f20773e496901852e56868369190e5615518b8` |
| [completed-trace-1280](.impeccable/review/completed-trace-1280.jpg) | 1280 × 1886 | `b6941c26ac00f1261f1f76910b65e17d40cf7ccc620e3d4dae18ede17aeb5467` |

Only this actual-1280px desktop owner-flow packet is approved. Mobile/390px, 1440px, touch, screen-reader behavior, exhaustive keyboard/hover/loading/empty/overlong coverage and all account/settings/restore/archive/publication/create/collection states remain unverified. The review records builder observations of native Enter, Tab/Return, focus, disclosure and KK language nodes, and a supplied empty mechanical detector result; those do not establish exhaustive accessibility or backend correctness. No security, restore-authenticity, concurrency or isolation certification follows.

The review's nonblocking notes remain open: mixed Russian/English checkpoint terminology, raw UTC retry timestamps, an enabled old save control after a stale refusal, and reported `config-build-path-unset` metadata drift. This documentation does not imply those notes were fixed. No UI edit is owed by the review or made by this pass.

## Elevation & Depth

No shadow, transition, animation or backdrop treatment is defined. Pale page ground, white native surfaces, one-pixel boundaries and section spacing convey hierarchy. Hover brightens buttons; primary hover also deepens the fill without motion. Programmatic task/preview-heading focus and the focused refusal notice provide continuity after content replacement. Source: [button states](public/styles.css#L120), [evidence boundary](public/styles.css#L166), [focus](public/styles.css#L246), [focus behavior](public/app.js#L5).

## Shapes

Controls and notices use the smaller recorded radius; form panels and table wrappers use the larger one. Buttons and native disclosure summaries have minimum height (44px). Textareas begin at minimum height (100px) and resize vertically. Native disclosure markers remain visible. There are no implemented chips, floating overlays or custom pickers to document. Source: [panels, forms and buttons](public/styles.css#L84), [disclosures](public/styles.css#L225), [tables](public/styles.css#L290).

## Components

### Buttons, Fields and Navigation

Primary and submit actions are green. Secondary refresh, return, open and archive controls are white with navy text and border; the navy-filled baseline remains defined in CSS. Buttons use the frontmatter inset and smaller radius, weight (600), hover brightness (1.13), disabled opacity (0.55) and final disabled `cursor: not-allowed`. Focus-visible uses an amber outline (3px) with offset (3px). The initiating asynchronous button disables during its request. Source: [button rules](public/styles.css#L120), [overrides](public/styles.css#L377), [request helper](public/app.js#L6).

Native text, search, number, password, file, select and rationale controls keep connected labels, full width, white ground, field stroke and blue carets. Recipe fields preserve their required/number-bound semantics; owner action uses a native select and rationale textarea. Read-only retained rationale keeps the textarea surface and native text selection. Source: [field helpers](public/app.js#L9), [draft editing](public/app.js#L28), [owner form](public/app.js#L35), [retained input](public/app.js#L36).

The navy header shows linked brand and account/role. Active collection navigation has a white bordered button and `aria-current="page"`; inactive buttons are transparent on Navigation Mist. Jobs is the initial collection. The skip link appears on focus; replaced task headings receive programmatic focus. Notices carry `role="status"`, `aria-live="polite"` and a focus target; empty notices hide. Refusal makes the notice pale red. Source: [shell semantics](public/index.html#L10), [navigation](public/app.js#L12).

### Record Table and Frozen Recipe

Search and archive visibility precede the native table. Column-scoped headers, left/top alignment, tabular numerals and wrapping cells keep text records readable. Every row has a secondary **Открыть** control. An empty filtered collection shows a written next step. The labelled focusable wrapper allows horizontal scrolling. Source: [records](public/app.js#L24), [table renderer](public/app.js#L26).

The native **Точный рецепт этого прогона** disclosure contains code/version, title, authored RU/KK instructions, attempt limit, retry delay and an ordered list of literal operations and declared synthetic faults. List item values preserve actual step positions. Publication preview says **Предпросмотр · ещё не опубликован** before its separate publish action. Creating a job says no step has executed. Source: [snapshot/publication](public/app.js#L29), [job creation](public/app.js#L32).

**The Frozen Recipe Rule.** Keep the job's exact publication and ordered step positions inspectable; a newer recipe never visually replaces the job snapshot.

### Owner Action, Preview and Saved Trace

An active, unarchived job owned by the current account exposes **Явное действие** and **Основание действия**. Other active readers see the written original-owner restriction. The select chooses advance/retry or cancellation; the server chooses the actual step. **Проверить действие без записи** reveals **Предпросмотр действия · ещё не записано**, future-worded status, attempt/position, checkpoint count and exact before/after text. Only the following **Записать только это действие** writes. Changing action or rationale clears the preview. Source: [result renderer](public/app.js#L33), [owner form](public/app.js#L35).

A refused save focuses the error notice and changes the preview heading to **Запись отказала · обновите прогон и проверьте снова** while retaining the form. The old save control remains enabled in this version; the fresh review records this as nonblocking. A successful save redraws the current state and ordered trace. Native trace disclosures show sequence/outcome, **Сохранённое событие**, saved status/count, before/after text, rationale and actor/time. Cancellation states **Отмена без выполнения шага** and records a separate terminal event. Source: [save/recovery branch](public/app.js#L35), [trace](public/app.js#L37).

**The Written State Rule.** Name unsaved, refused and saved states in text; a preview, count or color alone never asserts that an action was recorded.

The pending explanation names the earliest server timestamp and explicitly says refresh and elapsed time perform nothing. A transient failure retains the latest successful text; a later eligible owner command retries only the blocked step. Completed, failed and cancelled states remove the owner action form. Source: [job state and retry explanation](public/app.js#L34), [state derivation](public/app.js#L19), [product contract](PRODUCT.md).

**The Explicit Retry Rule.** Display retry eligibility as permission for a new owner command; refresh and elapsed time never claim execution.

### Refresh and Retained Input

**Обновить прогон** captures current unsaved action/rationale, fetches state and restores them to an eligible owner form without automatically sending. If the form is no longer available, retained values appear in a separate white panel headed **Несохранённый ввод после обновления**. It names the previous choice and uses a read-only **Несохранённое основание** textarea for copying; it does not replace the saved trace. Refresh/return peer buttons use a wrapping action group. Source: [retained branch](public/app.js#L36), [refresh/action group](public/app.js#L38).

**The Unsaved Recovery Rule.** Preserve action and rationale across explicit refresh; when the owner form is unavailable, keep retained text read-only and separate from the saved trace.

### Documentation Examples

The [schemaVersion 2 sidecar](.impeccable/design.json) supplies thirteen self-contained static synthetic examples extracted from current DOM/CSS: primary/secondary actions, collection navigation, labelled text field, job-creation panel, record table, frozen recipe disclosure, job state/checkpoint text, owner action form, unsaved action preview, saved trace event, refusal notice and read-only retained input. Every class uses a scoped `ds-` prefix. Action buttons use `type="button"` and have no application handlers; native fields and disclosures retain browser behavior. Compact examples do not simulate server execution and are not additional reviewed captures.

[PRODUCT.md](PRODUCT.md) and the [surface brief](.impeccable/surfaces/public-app-js.md) bound this interface to a synthetic local checkpoint/retry harness in one shared staff area. This visual contract does not add tenant isolation, integrations, background execution or evidence of actual work.

## Do's and Don'ts

### Do:

- Do retain the inherited navy shell, pale workspace, green explicit actions and white native controls.
- Do keep connected labels, visible focus, native disclosure markers and column-scoped table headers.
- Do preserve authored RU/KK instruction nodes, rationale, line breaks and real ordered step positions.
- Do show owner, written job state, saved-step count and event count before the action form.
- Do distinguish original input, latest saved text, an unsaved action preview and the immutable saved trace.
- Do keep every preview separate from its explicit save control and invalidate it when its form changes.
- Do describe cancellation as a separate saved event without step execution.
- Do retain action and rationale across refresh, with unavailable input separately read-only for copying.
- Do let long text, digests, table cells and timestamps wrap without fixed-height cropping.

### Don't:

- Don't replace the inherited identity with ornamental media, display lettering or animation.
- Don't replace native selects, tables or disclosures with decorative imitations.
- Don't present previewed or retained text as a saved checkpoint or event.
- Don't present elapsed time, refresh or a retry-eligibility timestamp as execution.
- Don't imply that a declared synthetic fault is a real infrastructure outage.
- Don't offer a different owner, an administrator bypass, reopening, reversal or editing of a saved event.
- Don't imply integrations, autonomous retries, AI, external tools, messages, payments or customer outcomes.
- Don't describe a digest, synthetic exercise or visual packet as authenticity or security certification.
- Don't expand the nine-state actual-1280px owner-flow verdict into mobile, accessibility, backend or full-product approval.
