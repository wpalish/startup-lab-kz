---
version: 1
slug: "public-app-js"
primary_target: "public/app.js"
related_targets: []
---

Scope: KadamRun public/app.js; Operate extension of own QaitaCycle Shared Work Cabinet, preserving native composition and navy/pale/green system.
## Direction contract
THESIS: An explicit retry resumes one frozen text step while previous successful checkpoints stay exact.
OWN-WORLD: Own inherited daylight cabinet, navy shell, pale workspace, green primary actions, white labelled forms, tabular evidence and native disclosures. No new identity, illustration or category dashboard.
STORY: Admin publishes ordered recipe and declared rehearsal faults. Owner creates job, sees checkpoint/trace, previews next command then explicitly saves one attempt or cancels. Server time only permits retry; it never acts.
FIRST VIEWPORT: Job title/owner, current state and checkpoint count precede original input/current text and the one-action owner form. Original bilingual recipe is a native disclosure. Preview separates planned result from saved trace. Signature: after transient failure, previous checkpoint remains exact and retry computes only the blocked step.
FORM: Narrow code-led extension of existing cabinet. Explicit user says continue100 and improve through relevant skills; task and inherited system settled, no world replacement or concept tournament. seed:none(inherited extension). Peer controls use wrapping actions gaps. Failed commands and refresh retain action/rationale; terminal recovery keeps unsaved text separately read-only.
FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance
