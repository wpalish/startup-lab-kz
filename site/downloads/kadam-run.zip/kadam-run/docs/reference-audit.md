# Reference17: Activepieces

[Officialhomepage](https://www.activepieces.com/) read26Oct2026: flows, retries/waitpoints/checkpoints and integrations are vendor descriptions. Metrics/security/customeroutcomes not independentlyverified/adopted. No account/forms/snippets/integrations used. Original KadamRun freezes literaltextrecipes and requires each ownercommand; no Activepiecescode/brand/AI/APIexecution.
