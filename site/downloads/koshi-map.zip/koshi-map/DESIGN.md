---
name: KoshiMap
description: An inherited working cabinet for exact named-column mappings, immutable synthetic sources and explicit whole-batch directory copying.
colors:
  primary: "#126653"
  primary-hover: "#0b5343"
  navy: "#183e60"
  ink: "#172e45"
  page: "#edf3f8"
  surface: "#ffffff"
  line: "#b9cbd9"
  navigation-surface: "#dce9f3"
  muted: "#46627a"
  input-stroke: "#7894aa"
  link: "#174e7e"
  pending: "#795200"
  error: "#942721"
  error-surface: "#fff0ee"
  focus: "#bd671a"
  selection-surface: "#b7ded2"
  selection-ink: "#132f29"
typography:
  primary-heading:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
    fontSize: "2rem"
    lineHeight: 1.15
    letterSpacing: "-0.025em"
  section-heading:
    fontSize: "1.3rem"
  brand:
    fontSize: "1.4rem"
    fontWeight: 740
  body:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
  label:
    fontWeight: 600
  supporting:
    fontSize: "0.9rem"
  exact-json:
    fontSize: "0.85rem"
rounded:
  control: "7px"
  panel: "12px"
spacing:
  evidence-gap: "0.4rem"
  inline-gap: "0.5rem"
  action-gap: "0.6rem"
  control-inset: "0.7rem"
  table-cell: "0.9rem"
  unit: "1rem"
  page-inline: "1.25rem"
  panel-inset: "1.4rem"
  section: "2rem"
  ordered-inset: "1.5rem"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-default:
    backgroundColor: "{colors.navy}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "{spacing.control-inset}"
    width: "100%"
  panel:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
    padding: "{spacing.panel-inset}"
  navigation-current:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  record-table:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
    width: "100%"
  record-table-heading:
    backgroundColor: "{colors.navigation-surface}"
    textColor: "{colors.ink}"
    typography: "{typography.supporting}"
    padding: "{spacing.table-cell}"
  snapshot-disclosure:
    padding: "0.7rem 0"
  error-notice:
    backgroundColor: "{colors.error-surface}"
    textColor: "{colors.error}"
    rounded: "{rounded.control}"
    padding: "{spacing.unit}"
---

# Design System: KoshiMap

## Overview

**Creative North Star: "The Shared Work Cabinet"**

KoshiMap extends its own BekitChange Shared Work Cabinet. It keeps navy identity and navigation, a pale blue workspace, white labelled forms and tables, green explicit actions, system typography and native controls. This is a narrow, code-led Operate extension with no replacement visual world or approved image comp. The public lineage is pinned to [BekitChange DESIGN.md](https://github.com/wpalish/bekit-change/blob/24b631888ddf3a4541cd9971da7c55fd0d8eee01/DESIGN.md) and its matching [design sidecar](https://github.com/wpalish/bekit-change/blob/24b631888ddf3a4541cd9971da7c55fd0d8eee01/.impeccable/design.json).

Its character is direct, flat and readable. An immutable synthetic batch leads with its owner, time, publication version and row count; exact source and mapping remain available in native disclosures. Current-target decisions precede the original author's explicit whole-copy action. The signature is one conflicting code closing the entire action while every row stays visible, followed by clearly separate saved decisions in past tense. Exact archived matches remain skipped without restoring visibility.

**Key Characteristics:**

- Inherited navy navigation and pale blue workspace.
- White bordered native forms and tables with green explicit actions.
- System typography, fixed-size task headings and readable paragraph measures.
- Exact authored RU/KK values and five named target fields before action.
- Immutable publication, full source and mapped values kept distinct from target decisions.
- One conflict closes the whole-copy action while preserving every row.
- Current preview, refused save and saved past-tense report have different headings.
- Zero-add copies remain saved operations; archived entries keep their occupied codes.
- Native disclosures, wrapping evidence and visible focus.

## Colors

The inherited cool palette uses Cabinet Navy for orientation and Working Green for explicit actions. The frontmatter owns implemented values. Sidecar tonal strips are derived inspection metadata inherited from the identical palette; they are not additional interface colors. The source is the [root palette and control rules](public/styles.css#L1-L15), with literal state colors in the same stylesheet.

### Primary

- **Working Green** (`primary`, `primary-hover`): explicit primary actions, source/mapping checks and submit buttons. Written report decisions carry the state; they do not depend on green badges.

### Secondary

- **Cabinet Navy** (`navy`): header, baseline filled actions, navigation text and secondary-control borders.
- **Link Blue** (`link`): operator-entered citation links and field carets.

### Tertiary

- **Pending Amber** (`pending`): retained pending utility; report decisions are expressed in words.
- **Error Red / Pale Error** (`error`, `error-surface`): whole-copy conflict and refused-save notices.
- **Focus Amber** (`focus`): visible focus on fields, actions, table scrolling regions and native disclosures.
- **Soft Selection Green / Selection Ink** (`selection-surface`, `selection-ink`): native text selection.

### Neutral

- **Cabinet Ink** (`ink`): root text, headings and exact record values.
- **Cool Workspace** (`page`): page ground and scrollbar track.
- **White Surface** (`surface`): fields, form panels, tables, ordinary notices and current navigation.
- **Divider Blue** (`line`): panel/table outlines, rows and evidence dividers.
- **Navigation Mist** (`navigation-surface`): navigation strip and table headings.
- **Supporting Slate** (`muted`): local/synthetic boundaries, helpers, digest and footer.
- **Field Slate** (`input-stroke`): native field borders and scrollbar thumb.

**The Inherited Shell Rule.** Extend the existing BekitChange cabinet palette, typography and navigation grammar.

## Typography

The recorded system stack serves headings, body and controls. No webfont is loaded. The main heading uses the recorded fixed size and tracking; section headings are smaller and the brand uses the recorded heavier weight. Unspecified body size, heading weights and line heights retain browser defaults. Preformatted source JSON and journal data use the native browser face at the recorded smaller size, rather than a separate display identity.

Paragraphs have maximum measure (72ch), line height (1.6) and ordinary margins. Labels and buttons use weight (600). Tables use tabular numerals and left/top alignment. Authored values preserve line breaks with `white-space: pre-wrap`. Exact codes are repeated as strong text below the decision heading. Written decisions, counts and recovery copy carry meaning independently of color. Source: [headings and paragraph rules](public/styles.css#L63-L77), [fields and labels](public/styles.css#L91-L118), [authored value renderer](public/app.js#L29-L32).

The document language is Russian. Mapping descriptions and directory RU/KK titles have separate `lang="ru"` and `lang="kk"` nodes; mapping editors mark their two description fields likewise. The collection table marks the KK entry cell. City, code, source URL, diagnostics and interface labels remain Russian interface context. The application does not infer or translate authored language. The five mapped fields are copied exactly; there is no trim, case, NFKC or semantic transformation of their values in the mapping step.

**The Authored Value Rule.** Preserve exact RU/KK values, language nodes and line breaks; mapping does not translate or normalize them.

## Layout

Header and navigation share inline padding (`max(1.25rem, calc((100% - 1160px) / 2))`). Main is centered with maximum width (1200px), padding (`2rem 1.25rem`) and minimum height (75vh). Header is a spaced flex row. Navigation and action rows use compact recorded gaps; actions wrap. The retained optional work grid uses columns (`minmax(0, 1fr) minmax(260px, 0.8fr)`), while paired rows use equal columns. Batch detail uses a vertical reading order on the pale page ground; a white panel identifies the available copy form. Source: [shell and grids](public/styles.css#L26-L90), [actions and paired rows](public/styles.css#L144-L154).

The detail sequence is batch title/row count, author/time/publication version, full saved source disclosure, exact published mapping disclosure, saved copy identity/reason or a current-target check, every row decision with exact mapped values and relevant target disclosure, archive non-revival explanation, any allowed copy form, then refresh/return actions. The original source remains separate from the directory before and after copying. Counts are plain text near their report heading rather than ornamental metrics.

Source declares a stacked breakpoint (700px and below): optional grids stack, main padding becomes (`1.4rem 1rem`), panel padding becomes (1rem), navigation wraps with padding (0.6rem), and header identity uses size (0.8rem) and maximum width (140px) while aligning to the top. At the narrow table/search breakpoint (600px and below), search tools stack, navigation buttons use `flex: auto`, cells receive minimum width (140px), table type becomes (0.9rem) and a horizontal-scroll hint appears. A labelled focusable table wrapper owns scrolling. These are [source-defined responsive rules](public/styles.css#L258-L375), not verified rendering at those widths.

Headings, header identity, evidence, disclosures, direct screen paragraphs and footer wrap long values. Ordered source/report rows use inset (1.5rem). Evidence uses a top border, unit top margin/padding and the recorded compact gap. No fixed-height crop truncates authored values, raw JSON or digests.

The [finish review](docs/finish-review.json) records a bounded `ship` verdict for six valid actual 1280 CSS-pixel states: [copy form](docs/copy-form-1280.jpg), [target conflict](docs/target-conflict-1280.jpg), [saved copy](docs/copied-1280.jpg), [stale refusal](docs/stale-refusal-1280.jpg), [zero-add copy](docs/zero-copy-1280.jpg) and [archived entry](docs/archived-entry-1280.jpg). This documentation pass opened all six as valid nonblank images and checked all six shipping/source pairs against their [capture provenance](docs/capture-provenance.json) hashes. Each pair contains byte-identical JPEGs from this product's own synthetic local browser workflow.

All six final captures were made after the final frontend clarification batch; their source render branches are unchanged since capture. They are authentic earlier workflow states, not a claim about the current terminal database or reopened immutable forms. The conflict image has zero insertion candidates: conflict alongside a still-new candidate is supported by source, not visually demonstrated in that image.

Only the six actual 1280px states and named current sources support the visual verdict. 390px/mobile, 1440px, other screens, exhaustive empty/overlong/hover/loading states, full keyboard paths, touch and screen-reader behavior remain unverified. This pass read source and images; it did not rerun the browser, interactions, backend tests, context or detector. The initial launcher-context limitation remains recorded in the finish review. Source semantics and this visual packet do not establish backend correctness, concurrency, account independence, restore authenticity, transport, security, real-data suitability, integrations or service outcomes.

## Elevation & Depth

No box shadow, backdrop effect, transition or animation is defined. Pale ground, white form/table surfaces, one-pixel borders and section spacing provide separation. Hover changes brightness and primary fill without motion. Replacing content and focusing the task or preview heading provides continuity. No decorative raster is used; the JPEGs are evidence assets with explicit provenance and temporal limits. Source: [state and focus styling](public/styles.css#L120-L143), [evidence separation](public/styles.css#L166-L172), [focus](public/styles.css#L247-L250).

## Shapes

Controls and notices use the smaller recorded radius; panels and table wrappers use the larger one. Borders are one pixel. Textareas start at height (100px) and resize vertically. Buttons and disclosure summaries have minimum height (44px). Native disclosure markers remain visible. Mapping uses a native definition list; source/report rows use an ordinary ordered list. Retained fieldset and recipient-choice rules do not define the batch-detail composition. Source: [panels and fields](public/styles.css#L84-L118), [disclosures and preformatted text](public/styles.css#L225-L238), [ordered inset](public/styles.css#L413).

## Components

### Buttons

Native labelled actions use padding (`0.65rem 1rem`) and the recorded label weight. Explicit primary and all submit buttons use Working Green with white text; hover combines the deeper primary fill with brightness (1.13). Secondary refresh, return, archive and settings actions use white with navy text and border. The retained baseline button rule is navy filled. Disabled buttons use opacity (0.55) and `cursor: not-allowed`. Focus-visible is an amber outline (3px) with offset (3px); source caps narrow buttons at width (100%). The initiating button is disabled during its asynchronous request. Source: [button rules](public/styles.css#L120-L143), [final overrides](public/styles.css#L377-L393), [run helper](public/app.js#L5-L7).

### Cards / Containers

Flat white form panels use a Divider Blue border, the panel radius and recorded inset, reduced at the stacked breakpoint. Login is capped at width (480px). Batch metadata, ordered decisions, saved copy identity and native disclosures stay on the pale page ground. Preview evidence follows the form without a modal.

### Inputs / Fields

Native inputs, selects and textareas use White Surface, Cabinet Ink, Field Slate borders and Link Blue carets. Generated fields have connected labels and unique IDs. Required publication, source JSON and copy-reason fields retain native required semantics. Archived or role-protected mapping editors preserve values through read-only inputs. Source JSON uses maximum length (80000); there is no editable directory form.

The batch editor has a publication selector, a labelled synthetic JSON textarea and **Проверить исходные строки**. The copy form has required **Основание копирования** and **Скопировать весь пакет один раз**. Input values remain present when a command fails because the successful detail replacement has not run. The result heading then states **Сохранение отказало · перепроверьте цель**, while the focused error notice gives recovery. A retained note is unsaved input, not a saved reason. Source: [field helpers](public/app.js#L9-L10), [batch editor and copy handler](public/app.js#L35-L41).

### Navigation and Notices

The linked brand and current account/role lead the navy header. Inactive section buttons are transparent on the pale strip; the current collection is white bordered with `aria-current="page"`. Source batches (`batches`) is the initial collection. The skip link becomes visible on focus. Task changes focus the leading heading using `tabindex="-1"`; successful previews focus their result heading. The notice has `role="status"`, `aria-live="polite"` and a programmatic focus target. Empty notices are hidden. Refusals use Pale Error and Error Red; ordinary notices use White Surface. These source semantics and visible focus do not establish a complete keyboard or screen-reader audit. Source: [page shell](public/index.html#L10-L21), [navigation and focus](public/app.js#L11-L12).

### Native Record Table

Collection search and archive visibility precede a flat bordered table. Column headers have `scope="col"`; all values are left/top aligned, long values wrap, and the KK title cell is language-marked. A labelled focusable wrapper provides overflow. Empty results use a written instruction. Archive text is appended to the first cell. **Открыть** leads to the corresponding detail; new copy/entry actions route to source batches because there is no direct directory editor. Source: [collection rendering](public/app.js#L23-L27), [table rules](public/styles.css#L290-L320).

### Immutable Publication and Source Disclosures

Mapping preview shows the exact code/version, title, RU/KK descriptions, declared source headers and five field-to-column pairs before **Опубликовать точное сопоставление**. Changing the selector clears the preview; generation checks discard obsolete responses. Publication detail includes author/time and digest. The saved source freezes that publication, full raw JSON including additional declared columns, mapped rows, owner and time. Source preview says **Исходный пакет · пока не сохранён**, explains that target matching has not run, and only then offers **Сохранить неизменный источник**. Input/change clears that preview and invalidates pending responses.

Batch detail keeps **Полный сохранённый источник JSON** and **Точное опубликованное сопоставление** in separate native disclosures. The mapping disclosure uses a definition list for exactly `code`, `titleRu`, `titleKk`, `city` and `sourceUrl`. Publication/source validation is not current-target comparison or permission to copy. Source: [mapping and value rendering](public/app.js#L29-L31), [publication/source flow](public/app.js#L33-L36), [immutable domain fields](module.js#L13-L30).

**The Snapshot Separation Rule.** Keep immutable publication and source evidence separate from the current-target preview and saved copy decisions.

### Current Target Preview and Whole-Copy Conflict

**Проверить текущую цель** produces **Предпросмотр цели · пока не записано** and **К добавлению …** counts. Every ordered row retains its exact five mapped values and one written decision: add, exact skip, duplicate of a numbered source row, within-batch conflict or existing-target conflict. Relevant target values are separate under **Точная существующая цель · …**. Source URL is an operator-entered citation rendered as a link opening a new tab with `noopener noreferrer`; the application does not fetch or verify it or establish permission, content or freshness.

Only a ready report and the original batch owner receive the required reason and explicit whole-copy form. A ready report shown to another account names the original owner. Any conflict shows the whole-copy refusal and recovery to a new corrected source batch, preserves all rows and removes the form. Source supports keeping new insertion candidates visible beneath that refusal, even though the supplied conflict image has none. An archived source has its own written refusal. Preview does not reserve or add rows; current-target checking must remain distinct from immutable source evidence. Source: [report renderer](public/app.js#L32), [detail branches](public/app.js#L36-L41), [exact plan](module.js#L66-L79).

**The Whole Copy Rule.** One conflicting row closes the entire copy action; preserve every row and name the new-source-batch recovery.

### Saved Copy, Zero-Add Copy and Archived Entry

A successful explicit action replaces the form with **Копирование #…**, actor, time, saved reason, **Сохранённое решение копирования** and **Добавлено …** counts. Decisions use past tense: **Добавлена новая строка**, **Совпало с целью · пропущено**, **Повтор · не добавлен**. Relevant existing targets become **Снимок цели до копирования · …**, so they cannot be mistaken for a new current-target check. No repeat-copy form appears.

The copy row stores the required immutable batch reference and its digest, complete decision report with relevant target-before values, inserted entry IDs, server sequence, actor and time. Full mapping and raw JSON remain available through the mandatory batch relation; they are not duplicated inline into each copy row. Unrelated directory rows are not in the report. This [source relationship](module.js#L98-L112) and the clarified [product contract](PRODUCT.md) constrain the UI's snapshot wording; they are not a claim that the screen displays every backend field.

A ready exact-match batch can save a separate copy with zero new entries, consuming that batch. The saved zero-add state retains its copy identity and past-tense skip. Comparison includes archived entries; an exact archived match stays hidden. Archived entry detail leads with **… · Архив**, exact values and original-copy provenance, says read-only and that the code remains occupied, and offers only navigation to the source copy or back. There is no edit, restore or copy form on that detail. Source: [saved report](public/app.js#L32), [saved branch](public/app.js#L37), [entry detail](public/app.js#L42), [comparison and one-copy checks](module.js#L66-L79).

**The Saved Tense Rule.** Use preview language before saving and past-tense decisions only beside a saved copy identity.

**The Archive Non-Revival Rule.** An exact archived match remains a skip; a zero-add copy never restores its visibility or releases its code.

### Example and Evidence Boundary

The sidecar provides thirteen static, self-contained synthetic examples of the actual primitives and signature states. Native fields, links and disclosures retain their ordinary browser behavior; all action buttons are non-submitting and have no application handlers. These examples are documentation, not extra reviewed captures or executable copy workflows.

Only synthetic values belong in this product. Staff share one local area without tenant isolation. There is no scraping, browser extension, AI, contact enrichment, external CRM write, messaging or live Bardeen integration. The URL is a citation, not verified source evidence. The visual system follows the durable boundaries in [PRODUCT.md](PRODUCT.md), [README.md](README.md), [module.js](module.js) and the [six-block surface contract](.impeccable/surfaces/public-app-js.md).

## Do's and Don'ts

### Do:

- Do inherit the navy header, pale workspace, white native forms/tables and green explicit action.
- Do keep connected labels, column-scoped table headers, native disclosure markers and visible focus.
- Do preserve exact authored RU/KK values, language nodes and line breaks.
- Do show batch owner, time, immutable publication version and row count before target decisions.
- Do keep full saved source JSON and exact published mapping in separate disclosures.
- Do render every mapped row, its written decision and any relevant existing-target values.
- Do close the whole-copy form on any conflict and name a new corrected source batch as recovery.
- Do keep the original author's required reason and explicit one-time whole-copy action.
- Do distinguish current preview, refused save, saved copy identity and saved past-tense decisions.
- Do retain the unsaved note and change the result heading after a refused save.
- Do record zero-add copies as saved operations while keeping exact archived matches hidden.
- Do allow long authored text, URLs, account names, timestamps and digests to wrap.

### Don't:

- Don't replace the inherited cabinet identity with ornamental assets or animation.
- Don't hide labels or replace native tables, ordered lists and disclosures with decorative imitations.
- Don't present source validation as target comparison or a preview as a reservation or saved copy.
- Don't present a retained unsaved note or stale target report as a saved result.
- Don't offer partial import, overwrite, merge or a copy form while any row conflicts.
- Don't expose a non-author or administrator bypass for copying a batch.
- Don't offer repeat copy, editing, restoration or reversal of a saved directory entry.
- Don't substitute the current directory for a saved relevant target-before snapshot.
- Don't describe a copy row as an inline snapshot of the whole directory, mapping or raw source.
- Don't imply that an operator-entered source URL was fetched, verified or endorsed.
- Don't imply tenant isolation, live Bardeen connectivity, scraping, AI, CRM writes or real-data outcomes.
- Don't present a digest or bounded visual review as a signature or security certification.
- Don't claim 390px/mobile, 1440px, touch or screen-reader verification from the six 1280px captures.
