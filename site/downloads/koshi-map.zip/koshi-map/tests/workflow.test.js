import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import definition,{mappingFor,mapRows,parseRows,plan} from '../module.js';
import {WorkStore} from '../core/store.js';
import {createServer} from '../core/server.js';
const admin={name:'coordinator',role:'admin'},owner={name:'alpha',role:'operator'},other={name:'beta',role:'operator'};
const profile={code:'SYN_MAP',title:'Вымышленный справочник',descriptionRu:'Ручное сопоставление вымышленных строк',descriptionKk:'Ойдан шығарылған жолдарды қолмен сәйкестендіру',headers:'ref, ru, kk, place, url, memo',codeColumn:'ref',titleRuColumn:'ru',titleKkColumn:'kk',cityColumn:'place',sourceUrlColumn:'url'};
const source=(ref='A',ru='SYN',kk='Үлгі',place='Астана',url='https://example.test/a')=>({ref,ru,kk,place,url,memo:'Ignored but preserved source cell'});
const raw=(...r)=>JSON.stringify(r.length?r:[source()]);
const put=(s,c,data,id,actor=admin,revision=s.read().revision)=>s.transact({collection:c,operation:'save',id,data,revision},actor);
const last=(s,c)=>s.read().data[c].at(-1);
const clean=(c,r)=>Object.fromEntries(definition.collections.find(x=>x.key===c).fields.map(f=>[f.key,r[f.key]]));
const archive=(s,c,id)=>s.transact({collection:c,operation:'archive',id,revision:s.read().revision},admin);
function unchanged(s,fn){const before=s.read(),audit=s.db.prepare('SELECT * FROM audit ORDER BY rowid').all();assert.throws(fn);assert.deepEqual(s.read(),before);assert.deepEqual(s.db.prepare('SELECT * FROM audit ORDER BY rowid').all(),audit);}
function fixture(path){
 let clock=Date.parse('2026-10-25T18:00:00.000Z');
 const s=new WorkStore(definition,path,{now:()=>clock});put(s,'profiles',profile);const p=last(s,'profiles');
 const publish=()=>{put(s,'publications',{profile:p.id});return last(s,'publications');},pub=publish();
 const batch=(inputJson=raw(),who=owner,key=randomUUID(),publication=pub)=>{put(s,'batches',{publication:publication.id,inputJson,requestKey:key},undefined,who);return last(s,'batches');};
 const copy=(b,who=owner,key=randomUUID(),revision=s.read().revision)=>{put(s,'copies',{batch:b.id,note:'SYN: явное целое локальное копирование',requestKey:key},undefined,who,revision);return last(s,'copies');};
 return {s,p,pub,publish,batch,copy,set:t=>clock=t};
}
test('publication declares five different named columns and deterministic exact mapping',()=>{
 const f=fixture(),m=mappingFor(f.s.read().data,f.p.id);assert.deepEqual(m.report.headers,['ref','ru','kk','place','url','memo']);
 assert.deepEqual(mapRows(m.snapshot,raw()),[{code:'A',titleRu:'SYN',titleKk:'Үлгі',city:'Астана',sourceUrl:'https://example.test/a'}]);f.s.close();
});
test('incomplete drafts allowed;publication requires both languages,5..8 unique headers and distinct mappings',()=>{
 const f=fixture();for(const patch of [{descriptionKk:''},{headers:'ref,ru,kk,place'},{headers:'ref,ru,kk,place,url,url'},{headers:'ref,ru,kk,place,url,a,b,c,d'},{headers:'ref,ru,kk,place,bad-name'},{titleKkColumn:'ru'},{cityColumn:'unknown'}]){
  put(f.s,'profiles',{...profile,...patch},f.p.id);unchanged(f.s,()=>f.publish());
 }f.s.close();
});
test('content version increases only on changes;publication version cannot repeat after archive',()=>{
 const f=fixture();put(f.s,'profiles',profile,f.p.id);assert.equal(last(f.s,'profiles').version,1);unchanged(f.s,()=>f.publish());
 archive(f.s,'publications',f.pub.id);unchanged(f.s,()=>f.publish());put(f.s,'profiles',{...profile,descriptionRu:'Новая инструкция'},f.p.id);assert.equal(f.publish().profileVersion,2);f.s.close();
});
test('parser refuses syntax/root/missing/unknown/nested/nonstring and repeated decoded keys',()=>{
 const h=['ref','ru','kk','place','url','memo'];
 for(const x of ['{','{}','null','[]',raw({}),raw({...source(),extra:'x'}),raw({...source(),ref:1}),raw({...source(),memo:{}})] )assert.throws(()=>parseRows(x,h));
 assert.throws(()=>parseRows('[{"ref":"A","ru":"R","kk":"K","place":"C","url":"https://example.test/","memo":"x","m\\u0065mo":"y"}]',h),/decoded/);
 assert.equal(parseRows(raw({...source(),ru:'a"b'}),h)[0].ru,'a"b');
});
test('strict row/cell/raw limits accept30 and300,refuse31 and301 and80001',()=>{
 const h=['ref','ru','kk','place','url','memo'];assert.equal(parseRows(JSON.stringify(Array(30).fill(source())),h).length,30);
 assert.equal(parseRows(raw({...source(),memo:'x'.repeat(300)}),h)[0].memo.length,300);
 for(const x of [JSON.stringify(Array(31).fill(source())),raw({...source(),memo:'x'.repeat(301)}),' '.repeat(80001)])assert.throws(()=>parseRows(x,h));
});
test('mapped code must already be uppercase and sourceURL http(s)without credentials;both texts nonblank',()=>{
 const f=fixture();for(const patch of [{ref:' a '},{ref:'a'},{ref:'А'},{ref:'A'.repeat(41)},{url:'javascript:alert(1)'},{url:'https://user:secret@example.test/'},{url:'broken'},{kk:'   '}])unchanged(f.s,()=>f.batch(raw({...source(),...patch})));
 f.s.close();
});
test('mapping preserves exact spaces/case/Unicode and ignored source cells rather than cleaning',()=>{
 const f=fixture(),b=f.batch(raw(source('A',' SYN ','Үлгі',' Астана ')));
 assert.equal(b.mappedRows[0].titleRu,' SYN ');assert.equal(b.mappedRows[0].city,' Астана ');assert.equal(JSON.parse(b.inputJson)[0].memo,'Ignored but preserved source cell');
 f.copy(b);assert.equal(last(f.s,'entries').titleRu,' SYN ');f.s.close();
});
test('publication and batch snapshots survive later descriptions and column mapping edits',()=>{
 const f=fixture(),b=f.batch(),pub=structuredClone(f.pub);put(f.s,'profiles',{...profile,descriptionKk:'Жаңа',titleRuColumn:'memo'},f.p.id);
 assert.deepEqual(f.s.read().data.publications[0],pub);assert.deepEqual(f.s.read().data.batches[0],b);f.copy(b);assert.equal(last(f.s,'entries').titleRu,'SYN');f.s.close();
});
test('exact batch duplicates point at first source row;contradictory same code conflicts for all rows',()=>{
 const f=fixture(),a=mapRows(f.pub.snapshot,raw(source(),source())),p=plan(a,[]);assert.equal(p.counts.duplicates,1);assert.equal(p.rows[1].duplicateOf,1);assert.equal(p.insertions.length,1);
 const b=f.batch(raw(source(),source('A','OTHER')));assert.equal(plan(b.mappedRows,[]).counts.conflicts,2);unchanged(f.s,()=>f.copy(b));assert.equal(f.s.read().data.entries.length,0);f.s.close();
});
test('whole copy saves exact new entries,identical target skip and source duplicate decisions',()=>{
 const f=fixture();f.copy(f.batch());const b=f.batch(raw(source(),source('B'),source('B'))),c=f.copy(b);
 assert.deepEqual(c.report.counts,{inserted:1,skipped:1,duplicates:1,conflicts:0});assert.equal(c.insertedIds.length,1);assert.deepEqual(f.s.read().data.entries.map(e=>e.code),['A','B']);f.s.close();
});
test('one changed target blocks every new row;no partial write or audit',()=>{
 const f=fixture();f.copy(f.batch());const b=f.batch(raw(source('A','DIFFERENT'),source('NEW')));
 assert.equal(plan(b.mappedRows,f.s.read().data.entries).status,'conflict');unchanged(f.s,()=>f.copy(b));assert.deepEqual(f.s.read().data.entries.map(e=>e.code),['A']);f.s.close();
});
test('archived target keeps its code;identical skips without resurrection,different conflicts',()=>{
 const f=fixture();f.copy(f.batch());const e=last(f.s,'entries');archive(f.s,'entries',e.id);const c=f.copy(f.batch());assert.equal(c.report.counts.inserted,0);assert.equal(c.report.counts.skipped,1);assert.equal(last(f.s,'entries').archived,true);
 const different=f.batch(raw(source('A','DIFFERENT')));unchanged(f.s,()=>f.copy(different));f.s.close();
});
test('zero-new-row copy is saved once and consumes batch even with a new UUID',()=>{
 const f=fixture();f.copy(f.batch());const b=f.batch(),c=f.copy(b);assert.deepEqual(c.insertedIds,[]);assert.equal(c.seq,2);unchanged(f.s,()=>f.copy(b));assert.equal(f.s.read().data.entries.length,1);f.s.close();
});
test('only original batch author copies;admin cannot bypass,direct target save forbidden',()=>{
 const f=fixture(),b=f.batch();for(const who of [admin,other])unchanged(f.s,()=>f.copy(b,who));
 unchanged(f.s,()=>put(f.s,'profiles',profile,undefined,owner));unchanged(f.s,()=>put(f.s,'publications',{profile:f.p.id},undefined,owner));
 unchanged(f.s,()=>put(f.s,'entries',{code:'X',titleRu:'R',titleKk:'K',city:'C',sourceUrl:'https://example.test/'},undefined,admin));f.s.close();
});
test('global stale revision from an unrelated draft refuses copy atomically',()=>{
 const f=fixture(),b=f.batch(),v=f.s.read().revision;put(f.s,'profiles',{...profile,code:'OTHER'});unchanged(f.s,()=>f.copy(b,owner,randomUUID(),v));assert.equal(f.s.read().data.entries.length,0);f.s.close();
});
test('requestUUID global across batch/copy and never freed by archive',()=>{
 const f=fixture(),k=randomUUID(),b=f.batch(raw(),owner,k);unchanged(f.s,()=>f.copy(b,owner,k));const c=f.copy(b);archive(f.s,'batches',b.id);unchanged(f.s,()=>f.batch(raw(),owner,k));unchanged(f.s,()=>f.batch(raw(),owner,c.requestKey));f.s.close();
});
test('client cannot inject mappedRows,report,IDs,snapshots,actor or time',()=>{
 const f=fixture();put(f.s,'batches',{publication:f.pub.id,inputJson:raw(),requestKey:randomUUID(),mappedRows:[],owner:'beta',at:'1999',snapshot:{}},undefined,owner);const b=last(f.s,'batches');assert.equal(b.owner,'alpha');assert.equal(b.mappedRows.length,1);
 put(f.s,'copies',{batch:b.id,note:'SYN',requestKey:randomUUID(),report:{},insertedIds:['fake'],actor:'beta',at:'1999'},undefined,owner);const c=last(f.s,'copies');assert.equal(c.actor,'alpha');assert.equal(c.report.counts.inserted,1);assert.notEqual(c.insertedIds[0],'fake');f.s.close();
});
test('archived mapping/publication block new batches;old batch copies;batch archive closes copy;copies cannot archive',()=>{
 const f=fixture(),b=f.batch(),closed=f.batch(raw(source('C')));archive(f.s,'publications',f.pub.id);archive(f.s,'profiles',f.p.id);unchanged(f.s,()=>f.batch());const c=f.copy(b);archive(f.s,'batches',closed.id);unchanged(f.s,()=>f.copy(closed));unchanged(f.s,()=>archive(f.s,'copies',c.id));f.s.close();
});
test('batch/copy/target history cannot edit;clock rollback before batch or previous copy refuses',()=>{
 const f=fixture(),b=f.batch();unchanged(f.s,()=>put(f.s,'batches',clean('batches',b),b.id,owner));f.set(Date.parse(b.at)-1);unchanged(f.s,()=>f.copy(b));f.set(Date.parse(b.at));const c=f.copy(b),e=last(f.s,'entries');unchanged(f.s,()=>put(f.s,'copies',clean('copies',c),c.id,owner));unchanged(f.s,()=>put(f.s,'entries',clean('entries',e),e.id));
 const old=f.batch(raw(source('OLD')));f.set(Date.parse(b.at)+1000);f.copy(f.batch(raw(source('LATER'))));f.set(Date.parse(b.at)+500);unchanged(f.s,()=>f.copy(old));f.s.close();
});
test('two SQLite sessions compete for same target;stale copy refuses then fresh conflict refuses',()=>{
 const dir=mkdtempSync(join(tmpdir(),'koshi-race-')),path=join(dir,'x.sqlite'),f=fixture(path),a=f.batch(),b=f.batch(raw(source('A','OTHER'))),second=new WorkStore(definition,path),v=second.read().revision;f.copy(a);unchanged(second,()=>put(second,'copies',{batch:b.id,note:'SYN',requestKey:randomUUID()},undefined,owner,v));unchanged(second,()=>put(second,'copies',{batch:b.id,note:'SYN',requestKey:randomUUID()},undefined,owner));second.close();f.s.close();rmSync(dir,{recursive:true});
});
test('file restart and consistent SQLite backup preserve full source,mapping,target,copy and audit',()=>{
 const dir=mkdtempSync(join(tmpdir(),'koshi-file-')),path=join(dir,'x.sqlite'),f=fixture(path);f.copy(f.batch());archive(f.s,'entries',last(f.s,'entries').id);f.copy(f.batch());const before=f.s.read(),audit=f.s.db.prepare('SELECT * FROM audit ORDER BY rowid').all();f.s.db.exec("VACUUM INTO '"+join(dir,'backup.sqlite')+"'");f.s.close();
 for(const p of [path,join(dir,'backup.sqlite')]){const s=new WorkStore(definition,p);assert.deepEqual(s.read(),before);assert.deepEqual(s.db.prepare('SELECT * FROM audit ORDER BY rowid').all(),audit);s.close();}rmSync(dir,{recursive:true});
});
test('empty restore preserves complete history and author can copy a pending batch',()=>{
 const f=fixture();f.copy(f.batch());const b=f.batch(raw(source('B'))),backup=f.s.export(),s=new WorkStore(definition);s.restore(backup);assert.deepEqual(s.read().data,backup.data);put(s,'copies',{batch:b.id,note:'SYN',requestKey:randomUUID()},undefined,owner);assert.equal(s.read().data.entries.length,2);unchanged(s,()=>s.restore(backup));s.close();f.s.close();
});
test('corrupt publication/source/mapping/report/entry/key/sequence copies refuse empty restore without writes',()=>{
 const f=fixture();f.copy(f.batch());const backup=f.s.export();
 for(const mut of [x=>x.data.publications[0].digest='bad',x=>x.data.batches[0].mappedRows[0].code='FORGED',x=>x.data.batches[0].inputJson=raw(source('OTHER')),x=>x.data.copies[0].report.counts.inserted=99,x=>x.data.copies[0].seq=2,x=>x.data.copies[0].requestKey=x.data.batches[0].requestKey,x=>x.data.copies[0].actor='beta',x=>x.data.entries[0].titleRu='FORGED',x=>x.data.entries.push({...x.data.entries[0],id:randomUUID(),code:'EXTRA'})]){
  const bad=structuredClone(backup);mut(bad);const s=new WorkStore(definition);unchanged(s,()=>s.restore(bad));s.close();
 }f.s.close();
});
test('HTTP independently enforces authentication,role,origin,CSRF,cookie,privacy and author-only copy',async()=>{
 const {server,store}=createServer(definition,{admin:{username:'coordinator',password:'synthetic-admin-password'}});await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 async function req(path,method='GET',body,auth,extra={}){
  const r=await fetch(origin+path,{method,headers:{...(body?{'Content-Type':'application/json',Origin:origin}:{}),...(auth?{Cookie:auth.cookie,'X-CSRF-Token':auth.csrf}:{}),...extra},body:body?JSON.stringify(body):undefined});return {status:r.status,data:await r.json(),headers:r.headers};
 }
 async function login(username,password){const r=await req('/api/login','POST',{username,password});assert.equal(r.status,200);assert.match(r.headers.get('set-cookie'),/HttpOnly/);return {cookie:r.headers.get('set-cookie').split(';')[0],csrf:r.data.user.csrf};}
 try{
  for(const p of ['/api/state','/api/audit','/api/backup','/api/users'])assert.equal((await req(p)).status,401);
  const ad=await login('coordinator','synthetic-admin-password');assert.match(ad.cookie,/work_koshi_map_session=/);
  for(const username of ['alpha','beta'])assert.equal((await req('/api/users','POST',{username,password:'synthetic-staff-password',role:'operator'},ad)).status,201);
  const al=await login('alpha','synthetic-staff-password'),be=await login('beta','synthetic-staff-password'),f=fixture();store.restore(f.s.export());f.s.close();
  const cmd={collection:'batches',operation:'save',revision:store.read().revision,data:{publication:store.read().data.publications[0].id,inputJson:raw(),requestKey:randomUUID()}};
  assert.equal((await req('/api/command','POST',cmd,al,{Origin:'https://wrong.test'})).status,403);assert.equal((await req('/api/command','POST',cmd,al,{'X-CSRF-Token':'bad'})).status,403);
  assert.equal((await req('/api/backup','GET',undefined,al)).status,403);assert.equal((await req('/api/audit','GET',undefined,al)).status,403);
  assert.equal((await req('/api/command','POST',{collection:'profiles',operation:'save',revision:store.read().revision,data:profile},al)).status,400);
  assert.equal((await req('/api/command','POST',cmd,al)).status,200);const b=last(store,'batches'),copy={collection:'copies',operation:'save',revision:store.read().revision,data:{batch:b.id,note:'SYN',requestKey:randomUUID()}},before=store.read(),audit=store.db.prepare('SELECT * FROM audit').all();
  for(const who of [be,ad]){assert.equal((await req('/api/command','POST',copy,who)).status,400);assert.deepEqual(store.read(),before);assert.deepEqual(store.db.prepare('SELECT * FROM audit').all(),audit);}
  assert.equal((await req('/api/command','POST',copy,al)).status,200);assert.equal((await req('/api/command','POST',copy,al)).status,400);assert.equal(store.read().data.entries.length,1);
  assert.equal((await req('/api/state','GET',undefined,{...al,cookie:al.cookie.replace('koshi_map','bekit_change')})).status,401);
 }finally{await new Promise(r=>server.close(r));}
});
