---
version: 1
slug: "public-app-js"
primary_target: "public/app.js"
related_targets: ["public/styles.css","public/index.html"]
---

Scope: KoshiMap public/app.js; Operate; author enters synthetic source cells and explicitly copies a whole batch.
THESIS: One conflicting code protects the whole directory; exact archived matches never resurrect a row.
OWN-WORLD: Inherit own BekitChange Shared Work Cabinet navy navigation, pale workspace, green actions, white native labelled forms, readable bilingual text and wrapping evidence. Narrow code-led extension, no replacement world.
STORY: Admin publishes five named-column mappings; author freezes the source, previews current target decisions and explicitly copies the whole batch once. Another write invalidates old confirmation; conflicts produce no partial result.
FIRST VIEWPORT: Batch owner, immutable publication and row count; per-row insert/skip/duplicate/conflict decisions with exact mapped values and existing target; only then author action. Signature: new candidates remain visible while one conflict visibly closes whole-copy; saved copy and live preview have different headings.
FORM: Code-led inherited extension. Native forms, ordered row evidence and disclosures, focus and ru/kk authorship. No new visual world, comp, animation or seed roll owed for this scoped extension. User explicitly says continue queue without pausing; task/constraints and inherited world are settled.
FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance
