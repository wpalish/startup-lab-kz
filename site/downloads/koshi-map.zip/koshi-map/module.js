import {createHash,randomUUID} from 'node:crypto';
import {F,R,C,rows,byId,required,changed,immutable,unique,summary} from './core/rules.js';

const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const pick=(r,keys)=>Object.fromEntries(keys.map(k=>[k,r[k]]));
const uuid=x=>typeof x==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(x);
const code=x=>typeof x==='string'&&/^[A-Z][A-Z0-9_-]{0,39}$/.test(x);
const account=x=>typeof x==='string'&&/^[a-zA-Z0-9_.-]{3,80}$/.test(x);
const text=x=>typeof x==='string'&&x.trim().length>0&&x.length<=8000;
const version=x=>Number.isSafeInteger(x)&&x>0;
const time=x=>typeof x==='string'&&Number.isFinite(Date.parse(x))&&new Date(Date.parse(x)).toISOString()===x;
export const hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
export const fields=['code','titleRu','titleKk','city','sourceUrl'];
const mappingKeys=['id','code','title','descriptionRu','descriptionKk','headers',...fields.map(k=>k+'Column'),'version'];
const batchKeys=['publication','inputJson','requestKey','snapshot','publicationDigest','mappedRows','owner','at'];
export const entryValue=e=>pick(e,fields);
export function headersOf(p){
 const h=p.headers.split(',').map(x=>x.trim());
 required(h.length>=5&&h.length<=8&&new Set(h).size===h.length&&h.every(x=>/^[a-z][a-z0-9_]{0,31}$/.test(x)),'Нужны 5–8 разных имён столбцов: a-z, цифры, underscore.');
 return h;
}
export function checkMapping(p){
 required(p&&uuid(p.id)&&code(p.code)&&text(p.title)&&text(p.descriptionRu)&&text(p.descriptionKk)&&version(p.version),'Публикация требует код, название и оба описания RU/KK.');
 const headers=headersOf(p),selected=fields.map(k=>p[k+'Column']);
 required(selected.every(x=>headers.includes(x))&&new Set(selected).size===5,'Пять целевых полей должны ссылаться на пять разных объявленных столбцов.');
 return {headers,mapping:Object.fromEntries(fields.map(k=>[k,p[k+'Column']]))};
}
export function mappingFor(s,id){
 const p=byId(s,'profiles',id);required(!p.archived,'Сопоставление в архиве.');
 const snapshot=pick(p,mappingKeys);return {snapshot,digest:hash(snapshot),report:checkMapping(snapshot)};
}
// Syntax is parsed first; the flat string-pair scan additionally rejects repeated decoded keys.
export function parseRows(raw,headers){
 required(typeof raw==='string'&&raw.length<=80000,'JSON: максимум 80000 знаков.');
 let value;try{value=JSON.parse(raw);}catch{required(false,'Неверный JSON.');}
 required(Array.isArray(value)&&value.length>=1&&value.length<=30,'Пакет: массив 1–30 объектов.');
 for(const [i,r] of value.entries()){
  required(r&&typeof r==='object'&&!Array.isArray(r),'Строка '+(i+1)+': нужен объект.');
  required(same(Object.keys(r).sort(),[...headers].sort()),'Строка '+(i+1)+': ровно объявленные столбцы, без пропусков или лишних.');
  for(const k of headers)required(typeof r[k]==='string'&&r[k].length<=300,'Строка '+(i+1)+', '+k+': строка до 300 знаков.');
 }
 const pair=/("(?:[^"\\]|\\.)*")\s*:\s*("(?:[^"\\]|\\.)*")/y;
 let at=raw.indexOf('[')+1;const ws=()=>{while(at<raw.length&&/\s/.test(raw[at]))at++;};ws();
 for(let i=0;i<value.length;i++){
  required(raw[at++]==='{','Неверный объект JSON.');ws();const keys=new Set();
  while(raw[at]!=='}'){
   pair.lastIndex=at;const m=pair.exec(raw);required(m,'Неверная ячейка JSON.');
   const k=JSON.parse(m[1]);required(!keys.has(k),'Повтор decoded-столбца: '+k+'.');keys.add(k);
   at=pair.lastIndex;ws();if(raw[at]===','){at++;ws();}else break;
  }
  required(raw[at++]==='}','Неверный объект JSON.');ws();if(raw[at]===','){at++;ws();}
 }
 return value.map(r=>pick(r,headers));
}
export function mapRows(snapshot,raw){
 const {headers,mapping}=checkMapping(snapshot),source=parseRows(raw,headers);
 return source.map((r,i)=>{
  const out=Object.fromEntries(fields.map(k=>[k,r[mapping[k]]]));
  required(code(out.code),'Строка '+(i+1)+': code уже должен быть ASCII uppercase, 1–40 знаков.');
  required(fields.every(k=>text(out[k])),'Строка '+(i+1)+': все пять целевых полей должны быть непустыми.');
  let u;try{u=new URL(out.sourceUrl);}catch{required(false,'Строка '+(i+1)+': неверная ссылка источника.');}
  required(['http:','https:'].includes(u.protocol)&&!u.username&&!u.password,'Ссылка источника http(s), без credentials.');
  return out;
 });
}
export function plan(mappedRows,entries){
 const groups=new Map();mappedRows.forEach((r,i)=>groups.set(r.code,[...(groups.get(r.code)||[]),i]));
 const result=[],insertions=[];let skipped=0,duplicates=0,conflicts=0;
 mappedRows.forEach((value,i)=>{
  const group=groups.get(value.code),target=entries.find(e=>e.code===value.code);
  let decision,duplicateOf=null;
  if(group.some(j=>!same(mappedRows[j],mappedRows[group[0]]))){decision='conflict_batch';conflicts++;}
  else if(group[0]!==i){decision='duplicate_of';duplicateOf=group[0]+1;duplicates++;}
  else if(!target){decision='insert';insertions.push(value);}
  else if(same(entryValue(target),value)){decision='skip_identical';skipped++;}
  else{decision='conflict_target';conflicts++;}
  result.push({row:i+1,value,decision,duplicateOf,target:target?{id:target.id,...entryValue(target)}:null});
 });
 return {status:conflicts?'conflict':'ready',rows:result,insertions,counts:{inserted:insertions.length,skipped,duplicates,conflicts}};
}
const used=(s,k)=>[...rows(s,'batches'),...rows(s,'copies')].some(r=>r.requestKey===k);
const batchDigest=r=>hash(pick(r,batchKeys));
export default {
 slug:'koshi-map',title:'KoshiMap',reference:14,description:'Именованные столбцы → неизменный синтетический пакет → проверка совпадений и атомарное добавление справочника.',
 limitations:'Общая локальная область · Только синтетические строки · Без скрейпинга, AI, контактов и внешних записей',
 collections:[
  C('profiles','Сопоставления',[F('code','Код сопоставления'),F('title','Название'),F('descriptionRu','Описание RU','textarea',{required:false}),F('descriptionKk','Описание KK','textarea',{required:false}),F('headers','Исходные столбцы через запятую','text',{required:false}),...fields.map(k=>F(k+'Column','Столбец для '+k,'text',{required:false}))],{writeRole:'admin',addLabel:'Создать сопоставление',description:'Admin объявляет 5–8 столбцов и пять разных соответствий. Черновик может быть неполным.'}),
  C('publications','Публикации',[R('profile','Сопоставление','profiles',{readOnly:true})],{writeRole:'admin',addLabel:'Проверить и опубликовать',description:'Точная неизменная версия обоих описаний и полного mapping. Повтор версии запрещён.'}),
  C('batches','Исходные пакеты',[R('publication','Публикация','publications',{readOnly:true}),F('inputJson','Синтетические строки JSON','textarea',{maxLength:80000}),F('requestKey','Ключ действия')],{addLabel:'Подготовить пакет',description:'1–30 вымышленных строк с точными опубликованными столбцами. Сохранение источника ещё не копирует его в справочник.'}),
  C('copies','Копирования',[R('batch','Исходный пакет','batches',{readOnly:true}),F('note','Основание копирования','textarea'),F('requestKey','Ключ действия')],{addLabel:'Копировать из пакета',description:'Только автор пакета, один раз. Любой конфликт закрывает весь copy; полного совпадения достаточно для нулевого добавления.'}),
  C('entries','Справочник',[...fields.map(k=>F(k,k))],{writeRole:'admin',addLabel:'Открыть исходные пакеты',description:'Только результаты целого copy, без прямого редактирования. Архив скрывает строку, но навсегда сохраняет её код в проверке совпадений.'})
 ],
 preview(s,input){
  if(input.mode==='profile')return mappingFor(s,input.profile);
  if(input.mode==='batch'){const p=byId(s,'publications',input.publication);required(!p.archived&&!byId(s,'profiles',p.profile).archived,'Публикация или сопоставление в архиве.');return {snapshot:p.snapshot,mappedRows:mapRows(p.snapshot,input.inputJson)};}
  required(input.mode==='copy','Неизвестный просмотр.');const b=byId(s,'batches',input.batch);required(!b.archived&&!rows(s,'copies').some(c=>c.batch===b.id),'Пакет в архиве или уже скопирован.');return {batch:b,report:plan(b.mappedRows,rows(s,'entries'))};
 },
 normalizeRow(key,row,s,old,actor,context){
  if(key==='profiles')return {...row,version:old?old.version+(Object.keys(row).some(k=>row[k]!==old[k])?1:0):1};
  const at=new Date(context.now).toISOString();
  if(key==='publications'){required(!old,'Публикация неизменна.');const p=mappingFor(s,row.profile);return {...row,...p,profileVersion:p.snapshot.version,publishedBy:actor.name,publishedAt:at};}
  required(key!=='entries','Справочник создаётся только целым копированием пакета.');
  required(!old,'Пакет и копирование неизменны.');required(uuid(row.requestKey)&&!used(s,row.requestKey),'Нужен новый, ещё не использованный UUID.');
  if(key==='batches'){
   const p=byId(s,'publications',row.publication);required(!p.archived&&!byId(s,'profiles',p.profile).archived,'Публикация или сопоставление в архиве.');
   return {...row,snapshot:p.snapshot,publicationDigest:p.digest,mappedRows:mapRows(p.snapshot,row.inputJson),owner:actor.name,at};
  }
  const b=byId(s,'batches',row.batch);required(!b.archived,'Пакет в архиве.');required(actor.name===b.owner,'Копирует только первоначальный автор пакета.');required(!rows(s,'copies').some(c=>c.batch===b.id),'Пакет уже скопирован.');
  required(at>=b.at&&(!rows(s,'copies').length||at>=rows(s,'copies').at(-1).at),'Серверное время раньше пакета или предыдущего копирования.');
  const report=plan(b.mappedRows,rows(s,'entries'));required(report.status==='ready','В пакете или цели конфликт: целиком отказано, ничего не добавлено.');
  const insertedIds=[];for(const value of report.insertions){const id=randomUUID();insertedIds.push(id);s.entries.push({...value,id,seq:s.entries.length+1,copyKey:row.requestKey,createdAt:at,updatedAt:at,createdBy:actor.name,archived:false});}
  return {...row,seq:rows(s,'copies').length+1,report,insertedIds,batchDigest:batchDigest(b),actor:actor.name,at};
 },
 validate(s,before,command){
  if(command.operation==='archive')required(command.collection!=='copies','Копирования нельзя скрыть архивом.');
  unique(rows(s,'profiles'),'code','Код сопоставления');
  for(const p of rows(s,'profiles'))required(code(p.code)&&text(p.title)&&version(p.version)&&['descriptionRu','descriptionKk','headers',...fields.map(k=>k+'Column')].every(k=>typeof p[k]==='string'&&p[k].length<=8000),'Неверный черновик сопоставления.');
  const versions=new Set();
  for(const p of rows(s,'publications')){
   const parent=byId(s,'profiles',p.profile),v=p.profile+':'+p.profileVersion;
   required(p.snapshot.id===parent.id&&p.profileVersion===p.snapshot.version&&p.profileVersion<=parent.version&&same(checkMapping(p.snapshot),p.report)&&p.digest===hash(p.snapshot)&&account(p.publishedBy)&&time(p.publishedAt)&&p.createdBy===p.publishedBy&&p.createdAt===p.publishedAt&&!versions.has(v),'Неверная или повторная публикация.');versions.add(v);
   immutable(changed(before,'publications',p.id),p,['profile','snapshot','digest','report','profileVersion','publishedBy','publishedAt']);
  }
  const keys=new Set();
  for(const key of ['batches','copies'])for(const r of rows(s,key)){required(uuid(r.requestKey)&&!keys.has(r.requestKey),'Повтор UUID.');keys.add(r.requestKey);}
  for(const b of rows(s,'batches')){
   const p=byId(s,'publications',b.publication);
   required(same(b.snapshot,p.snapshot)&&b.publicationDigest===p.digest&&same(b.mappedRows,mapRows(b.snapshot,b.inputJson))&&account(b.owner)&&time(b.at)&&b.owner===b.createdBy&&b.at===b.createdAt,'Нарушен снимок исходного пакета.');
   immutable(changed(before,'batches',b.id),b,batchKeys);
  }
  const copied=new Set(),claimed=new Set(),head=[];let seq=0,previousTime='';
  for(const c of rows(s,'copies')){
   const b=byId(s,'batches',c.batch),expected=plan(b.mappedRows,head);
   required(c.seq===++seq&&!copied.has(b.id)&&expected.status==='ready'&&same(c.report,expected)&&c.batchDigest===batchDigest(b)&&c.actor===b.owner&&c.createdBy===c.actor&&time(c.at)&&c.createdAt===c.at&&c.at>=b.at&&c.at>=previousTime&&text(c.note)&&!c.archived,'Нарушена целая копия или её последовательность.');
   required(Array.isArray(c.insertedIds)&&c.insertedIds.length===expected.insertions.length,'Неверный список добавленных строк.');
   copied.add(b.id);previousTime=c.at;
   c.insertedIds.forEach((id,i)=>{
    const e=byId(s,'entries',id);required(!claimed.has(id)&&same(entryValue(e),expected.insertions[i])&&e.seq===head.length+1&&e.copyKey===c.requestKey&&e.createdBy===c.actor&&e.createdAt===c.at,'Нарушена добавленная строка.');
    claimed.add(id);head.push(e);
   });
   immutable(changed(before,'copies',c.id),c,['batch','note','requestKey','seq','report','insertedIds','batchDigest','actor','at']);
  }
  required(claimed.size===rows(s,'entries').length,'Справочник содержит строку без копирования.');
  const codes=new Set();for(const e of rows(s,'entries')){
   required(code(e.code)&&!codes.has(e.code),'Повтор кода справочника.');codes.add(e.code);
   immutable(changed(before,'entries',e.id),e,[...fields,'seq','copyKey','createdBy','createdAt']);
  }
 },
 summarize(s){return summary('Копирование и справочник',...rows(s,'copies').map(c=>'#'+c.seq+' · добавлено '+c.report.counts.inserted+' · совпало '+c.report.counts.skipped+' · '+c.actor));}
};
