# Workspace

Mode: Operate. Established KezekShift/JolFlow cabinet; inherit its palette/components, no new visual world.

## Direction contract

THESIS: Publish authored literal routing rules, then compare every case in a selected suite against the immutable version. The report explains conflicts and no-match without claiming AI quality.

OWN-WORLD: Inherited navy header, pale blue ground, white native forms and green labelled actions. System type, visible focus, wrapping evidence, no decorative assets or animation.

STORY: Author rules and expected examples separately; inspect a batch preview, explicitly save the run, then read mismatch evidence and historical versions.

FIRST VIEWPORT: Runs heading and primary Run suite action, followed by versioned records. Report leads with passed/total and explicit mismatches; each case reveals normalized input, expected/actual and matched rule codes. Publication preview shows rules before one save action. Signature: case disclosure keeps expected/actual adjacent.

FORM: Precise task extension of the established Operate cabinet; no concept tournament or comp. seed: none (unavailable).

FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance

## Implemented surface record

- Documentation: `../../DESIGN.md` and `../design.json` record the shipped inherited cabinet from `public/styles.css`, `public/app.js`, `public/index.html` and the six supplied review captures.
- Finish review: `../../../../program/syna-route-finish-review.json` records `ship` for the reviewed source/capture states. This is not a full external security audit or an independent rerun of backend/mobile checks.
- Case signature: report count and source versions precede native disclosures; expected/actual remain adjacent, followed by normalized input, matched rule codes and highest-priority routes. Mismatches open by default; captured passing cases were also opened for inspection.
- Preview and save: source selectors precede computation; a selector change clears evidence; a separate green action explicitly saves the publication or run. Preview is not saving or proof of human approval.
- Versioned captures: historical saved report rules v4 / suite v5 at 2/3 (1440/1280/390), current preview rules v4 / suite v6 at 2/3 (1440/390), and saved conflict rules v5 / suite v6 at 3/3 with HUMAN and SALES candidates (1440).
- Wrapping correction: direct screen paragraphs use `overflow-wrap: anywhere` so request keys and SHA256 digest evidence remain visible at 390px. Supplied measurements report scroll width equal to viewport width; documentation opened the images without rerunning the browser or detector.
