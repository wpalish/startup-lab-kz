---
name: SynaRoute
description: An inherited working cabinet for literal routing rules, explicit batch saves, and inspectable expected-versus-actual evidence.
colors:
  primary: "#126653"
  primary-hover: "#0b5343"
  navy: "#183e60"
  ink: "#172e45"
  page: "#edf3f8"
  surface: "#ffffff"
  line: "#b9cbd9"
  navigation-surface: "#dce9f3"
  muted: "#46627a"
  input-stroke: "#7894aa"
  link: "#174e7e"
  pending: "#795200"
  error: "#942721"
  error-surface: "#fff0ee"
  focus: "#bd671a"
  selection-surface: "#b7ded2"
  selection-ink: "#132f29"
typography:
  primary-heading:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
    fontSize: "2rem"
    lineHeight: 1.15
    letterSpacing: "-0.025em"
  section-heading:
    fontSize: "1.3rem"
  brand:
    fontSize: "1.4rem"
    fontWeight: 740
  body:
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
  label:
    fontWeight: 600
  evidence-label:
    fontWeight: 650
  supporting:
    fontSize: "0.9rem"
rounded:
  control: "7px"
  panel: "12px"
spacing:
  evidence-gap: "0.4rem"
  inline-gap: "0.5rem"
  action-gap: "0.6rem"
  control-inset: "0.7rem"
  unit: "1rem"
  page-inline: "1.25rem"
  panel-inset: "1.4rem"
  section: "2rem"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  button-default:
    backgroundColor: "{colors.navy}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "{spacing.control-inset}"
    width: "100%"
  panel:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
    padding: "{spacing.panel-inset}"
  navigation-current:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    rounded: "{rounded.control}"
    padding: "0.65rem 1rem"
  case-disclosure:
    typography: "{typography.evidence-label}"
    padding: "0.7rem 0"
---

# Design System: SynaRoute

## Overview

**Creative North Star: "The Shared Work Cabinet"**

SynaRoute extends the documented KezekShift / JolFlow Operate cabinet. It keeps the navy identity and navigation, pale blue workspace, white labelled forms, green explicit actions, system typography, and native controls. The incumbent system remains the visual authority.

Its character is direct, flat, and readable. Authored rules and expected examples remain separate until a batch preview compares them. The report makes each expectation and actual result inspectable, while the explicit save preserves the selected source versions as historical evidence.

**Key Characteristics:**

- Inherited navy navigation and pale blue workspace.
- Green labelled actions and white bordered form panels.
- System typography with a fixed-size task heading.
- Native case disclosures with adjacent expected and actual values.
- Visible publication and suite versions; preview computation before explicit save.
- Wrapping authored text, request keys, snapshot digests, and deliberate task focus.

## Colors

The cool inherited palette uses navy for orientation and Working Green for explicit actions. The frontmatter owns the implemented values. Sidecar tonal strips are derived inspection metadata, not additional interface colors.

### Primary

- **Working Green** (`primary`, `primary-hover`): submit, publication and run-save actions; the inherited status utility uses the same green.

### Secondary

- **Cabinet Navy** (`navy`): header, default filled controls, navigation text and secondary borders.
- **Link Blue** (`link`): links and field carets.

### Tertiary

- **Pending Amber** (`pending`): inherited pending utility.
- **Error Red / Pale Error** (`error`, `error-surface`): refusal notice.
- **Focus Amber** (`focus`): visible keyboard and programmatic focus outline.
- **Soft Selection Green / Selection Ink** (`selection-surface`, `selection-ink`): native text selection.

### Neutral

- **Cabinet Ink** (`ink`): root text.
- **Cool Workspace** (`page`): page ground and scrollbar track.
- **White Surface** (`surface`): forms, ordinary notices and current navigation.
- **Divider Blue** (`line`): containers, tables and evidence dividers.
- **Navigation Mist** (`navigation-surface`): navigation strip and table headings.
- **Supporting Slate** (`muted`): helper copy and footer.
- **Field Slate** (`input-stroke`): field borders and scrollbar thumb.

**The Inherited Shell Rule.** Extend the current KezekShift / JolFlow cabinet instead of replacing its palette, typography, or navigation grammar.

## Typography

The system stack in the frontmatter serves task headings, body and controls. No webfont is loaded; unspecified sizes and weights retain browser defaults. This is a task hierarchy, with a fixed-size primary heading, a smaller section heading and heavier brand text, rather than a display-type treatment.

Paragraphs have a maximum measure of 72ch and line height 1.6. Labels and buttons use weight 600; case summaries and legends use weight 650. Supporting text uses the smaller recorded size. Authored input and rule text preserve line breaks. Audit text wraps anywhere at 0.85rem; table values use tabular numerals. The root body size and line height are not explicitly declared.

The Russian interface inherits `lang="ru"`. Rule needles and case input fields update their language semantics from the authored language selector. Rule needles, case input and normalized case input in evidence carry `kk` for authored KK; other values, including a rule authored for both languages, use `ru`. Language is authored, not detected or translated. Expected/actual labels, route codes, matched rule codes and candidate-route explanations remain interface text.

**The Authored Language Rule.** Preserve authored RU/KK input semantics within the Russian interface without inventing language detection or translation.

## Layout

Header and navigation share `max(1.25rem, calc((100% - 1160px) / 2))` inline padding. Main is centered with maximum width 1200px, `2rem 1.25rem` padding and minimum height 75vh. Header uses a spaced flex row; navigation has a 0.5rem gap. The inherited optional work grid has `minmax(0, 1fr) minmax(260px, 0.8fr)` columns and 2rem gap; paired rows use equal columns and 1rem gap. SynaRoute preview and report screens use a vertical reading order.

At 700px and below, grids stack, main padding becomes `1.4rem 1rem`, panels use 1rem padding, and navigation wraps with 0.6rem padding. Identity aligns to the top, uses 0.8rem text and maximum width 140px. At 600px and below, navigation buttons use `flex: auto`, search tools stack, and table cells have minimum width 140px with 0.9rem table type. Table scrolling belongs to its focusable wrapper, accompanied by a narrow-screen hint.

Action rows wrap. Headings, identity, disclosures, evidence and footer use `min-width: 0` and wrapping rather than truncation. Direct screen paragraphs explicitly use `overflow-wrap: anywhere`, retaining request keys and SHA256 digests inside the viewport; the supplied narrow saved-report capture shows this correction. Preview evidence has a top divider, 1rem top padding/margin and 0.4rem grid gap. Its direct save button fills the grid width. Historical reports render directly on the page ground.

The documentation pass opened six supplied captures: historical saved report at 1440, 1280 and 390px; current preview at 1440 and 390px; and saved conflict report at 1440px. The finish review records `ship` for these source/capture states. The supplied measurements report scroll width equal to viewport width; this pass did not rerun a browser, backend, detector or mobile interaction check. The runs-list first viewport is evidenced by source, not a supplied list capture. These observations do not establish complete mobile, touch, screen-reader or security coverage.

## Elevation & Depth

No box shadow, backdrop effect, transition or animation is defined. White panels, pale fills, one-pixel borders and whitespace separate regions. Hover changes brightness and the primary fill without motion. Replacing screen content and focusing the task or preview heading provides interaction continuity without an animation system. No shipping raster imagery is used by the interface; review screenshots are evidence assets.

## Shapes

Controls and notices use the smaller recorded radius; panels and table wrappers use the larger one. Borders are one pixel. Textareas start at 100px height and resize vertically. Buttons and native disclosure summaries have minimum height 44px. Case summaries retain the browser's disclosure marker. Inherited fieldsets use the control radius, 1rem padding, and a labelled legend.

## Components

### Buttons

Native labelled actions use `0.65rem 1rem` padding and weight 600. Primary and submit actions use Working Green with white text; hover combines the deeper primary fill with brightness 1.13. Secondary actions use white, navy text and border. Default controls use navy fill. Disabled buttons use opacity 0.55 and `cursor: not-allowed`. Focus is a 3px amber outline with 3px offset; narrow buttons have maximum width 100%.

### Cards / Containers

White form panels use a Divider Blue border, panel radius and 1.4rem padding, reduced at the narrow breakpoint. Login is capped at 480px. Report evidence uses the page ground and dividers instead of another card. Publication and suite selectors stay inside the form above the preview result.

### Inputs / Fields

Native inputs, selectors and textareas use white fill, Cabinet Ink, Field Slate borders and Link Blue carets. Labels connect to generated field IDs. Archived or role-protected records retain their original values in native read-only/disabled fields. The expected route field is required only for an authored route expectation; it is cleared and disabled for no-match or conflict. Failed submissions retain the screen and use the focused polite status notice above it.

### Navigation

The linked brand and user/role lead the navy header. Inactive controls are transparent on the pale strip; the current section is white with a border and `aria-current="page"`. Navigation wraps. The skip link becomes visible on focus; task changes focus a heading with `tabindex="-1"`. The default section is **Прогоны**.

### Publication and Batch Preview

Publication preview selects an authored rulebook; batch preview selects an immutable publication and a suite. Publication labels include rulebook code and rule version; suite labels include suite code and version. The opening copy states that preview saves nothing and a later edit requires a fresh view. Computation appears after the form and focuses its leading result heading. Changing either selector clears evidence, and a generation guard ignores an obsolete response.

Rule preview shows the source code/version, title, normalization/priority explanation, and an ordered list of authored literal rules with language, match mode, priority, needle and route. **Опубликовать эту версию** follows the rules. Batch preview uses the report grammar below, followed by **Сохранить этот прогон**. The save is explicit; the interface's preview is not a required HTTP approval step or proof a person inspected the evidence. These behaviors are documented from source and supplied captures, not independently rerun here.

**The Explicit Save Rule.** Keep computation visibly separate from the one labelled action that saves a publication or run.

### Case Report and Historical Evidence

The report leads with passed/total, mismatch count, rulebook code/version and suite code/version. Each native case disclosure leads with code, authored language and **Совпало** or **Расхождение**. Mismatches open by default in source; passing cases remain available to open. The body presents authored input, then adjacent expected and actual kind/route values, normalized input, matched rule codes and highest-priority route candidates. Conflict and no-match remain explicit result kinds; empty matches/candidates say **нет**.

Saved-run detail adds actor/time and the immutable-snapshot explanation before the report, then a separate **Правила именно этого прогона** disclosure, request key and snapshot digest. Published-rule detail likewise identifies its exact snapshot and warns that the current draft may differ. List rows keep suite and rule versions beside the count. The SHA256 text is an inspectable digest label, not a signature or a security guarantee.

The historical captures show rules v4 / suite v5 at 2/3: a passing KK SALES route, RU expected HUMAN versus actual SALES, and explicit no-match evidence. The current preview shows rules v4 / suite v6 at 2/3, with RU expected conflict versus actual SALES. The saved conflict capture shows rules v5 / suite v6 at 3/3 and both HUMAN and SALES as the RU conflict candidates. These are separate source versions, not inconsistent depictions of one report. Matching the authored expectation measures this synthetic suite only.

**The Adjacent Evidence Rule.** Keep expected and actual values together inside each native case disclosure, followed by the normalization, matched rules and candidate routes that explain the result.

**The Historical Version Rule.** Preserve the saved rule and suite identities beside their result; later authored edits must not visually replace the historical evidence.

### Tables and Notices

Native full-width tables use collapsed borders, left/top aligned cells, 0.9rem padding, wrapping values, maximum cell width 28ch and pale header cells. Action text stays unbroken; the wrapper owns scrolling and visible focus. The last row removes its bottom divider. Refusals use pale red fill, error text and the focused `role="status"` / polite live notice. Ordinary notices use white fill. Success and failure remain textual rather than depending on color.

## Do's and Don'ts

### Do:

- **Do** inherit the navy header, pale workspace, white form surfaces and green primary action.
- **Do** keep native controls, case disclosure markers and visible focus.
- **Do** preserve authored RU/KK input semantics within Russian interface copy.
- **Do** allow long input, version labels, timestamps, request keys and SHA256 digests to wrap.
- **Do** show expected and actual values adjacent to the evidence explaining each case.
- **Do** separate preview computation from explicit save and retain historical source versions.

### Don't:

- **Don't** replace the inherited cabinet with a new visual identity.
- **Don't** clip historical evidence or remove the native case disclosure marker.
- **Don't** imply that preview saves a report or establishes human approval.
- **Don't** imply that passing authored cases proves real-dialogue, AI, translation, voice or external-message quality.
- **Don't** substitute current drafts for saved rule, suite or report snapshots.
- **Don't** present the displayed SHA256 digest as a signed export or security certification.
